--1 MGS
SELECT category_name 
FROM categories
WHERE NOT EXISTS
	(SELECT *
	 FROM products
	 WHERE category_id = categories.category_id)
GROUP BY category_name ASC;
	 
--2 MGS
SELECT email_address, MAX(t.order_total) 
FROM (
SELECT c.email_address, o.order_id, (SUM(((oi.item_price - oi.discount_amount) * oi.quantity)) + o.ship_amount + o.tax_amount) AS order_total 
FROM customers c NATURAL JOIN orders o NATURAL JOIN order_items oi 
GROUP BY email_address, order_id
) t
GROUP BY email_address;

--3 MGS
SELECT list_price, FORMAT(list_price, 1) AS list_price_FORMAT, CONVERT(list_price, SIGNED) AS list_price_CONVERT, CAST(list_price AS SIGNED) AS list_price_CAST 
FROM products;

--4 MGS
SELECT date_added, CAST(date_added AS DATE) AS date_added_DATE, CONCAT(YEAR(CAST(date_added AS DATE)), '-', MONTH(CAST(date_added AS DATE))) AS date_added_YM, CAST(date_added AS TIME) AS date_added_TIME 
FROM products;
 
--5 MGS
SELECT list_price, discount_percent, ROUND((list_price *(discount_percent / 100)), 2) AS discount_amount
FROM products
GROUP BY list_price ASC;
 
--6 MGS
SELECT order_date, DATE_FORMAT(order_date, '%Y') AS order_date_YEAR, DATE_FORMAT(order_date, '%b-%d-%Y') AS order_date_MonDDYYYY, DATE_FORMAT(order_date, '%l:%i %p') AS order_date_HMMAMPM, DATE_FORMAT(order_date, '%m/%d/%y %H:%i %p') AS order_date_MMDDYYHHMMAMAP
FROM orders;
 
--7 MGS
SELECT card_number, LENGTH(card_number) AS card_number_length, RIGHT(card_number, 4) AS card_number_last4, INSERT(RIGHT(card_number, 4), 1, 0, 'XXXX-XXXX-XXXX-') AS card_number_safe 
FROM orders;
 
--8 MGS
SELECT order_id, DATE(order_date) AS order_date, DATE_ADD(DATE(order_date), INTERVAL 2 DAY) AS approx_ship_date, DATE(ship_date) AS ship_date, DATEDIFF(ship_date, order_date) AS days_to_ship
FROM orders 
WHERE MONTH(order_date) = '04' AND YEAR(order_date) = '2012';
 
--9 ap
SELECT i.invoice_id, i.invoice_number, i.invoice_total, v.vendor_name 
FROM invoices i JOIN vendors v USING(vendor_id) 
WHERE i.invoice_total > 5000 
GROUP BY invoice_total DESC;
 
--10 ap
SELECT i.invoice_id, i.invoice_number, i.invoice_total, v.vendor_name 
FROM invoices i JOIN vendors v USING(vendor_id)
WHERE  
	(SELECT invoice_total
     FROM invoices 
	 WHERE invoice_id = i.invoice_id)
	> 5000
ORDER BY i.invoice_total DESC;
 
--11 mgs_amandac
--main query
SELECT o.order_id, DATE(o.order_date) AS order_date, o.tax_amount, DATE(o.ship_date) AS ship_date, oi.item_price, oi.discount_amount, (oi.item_price - oi.discount_amount) AS final_price, oi.quantity, (((oi.item_price - oi.discount_amount) + o.tax_amount) * oi.quantity) AS item_total, p.product_name 
FROM orders o JOIN order_items oi USING(order_id) JOIN products p USING(product_id) 
ORDER BY o.order_id ASC;
--view
CREATE OR REPLACE VIEW order_item_products AS
SELECT o.order_id, DATE(o.order_date) AS order_date, o.tax_amount, DATE(o.ship_date) AS ship_date, oi.item_price, oi.discount_amount, (oi.item_price - oi.discount_amount) AS final_price, oi.quantity, (((oi.item_price - oi.discount_amount) + o.tax_amount) * oi.quantity) AS item_total, p.product_name 
FROM orders o JOIN order_items oi USING(order_id) JOIN products p USING(product_id) 
ORDER BY o.order_id ASC;
 
--12 mgs_amandac
--main query
SELECT product_name, COUNT(product_name) AS order_count, SUM(item_total) AS order_total 
FROM order_item_products
GROUP BY product_name
ORDER BY product_name ASC;
--view
CREATE OR REPLACE VIEW product_summary AS
SELECT product_name, COUNT(product_name) AS order_count, SUM(item_total) AS order_total 
FROM order_item_products
GROUP BY product_name
ORDER BY product_name ASC;
 
--13 mgs_amandac
SELECT * 
FROM product_summary 
ORDER BY order_count DESC, order_total DESC
LIMIT 5;