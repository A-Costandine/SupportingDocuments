/********************************************************
* This script creates the database named exam_amandac 
*********************************************************/

DROP DATABASE IF EXISTS exam1_amandac;
CREATE DATABASE exam1_amandac;
USE exam1_amandac;

DROP table if exists users;
CREATE TABLE users
(
	user_id			INT				PRIMARY KEY		AUTO_INCREMENT,
	email_address	VARCHAR(100)	NOT NULL		UNIQUE,
	first_name		VARCHAR(45)		NOT NULL,
	last_name		VARCHAR(45)		NOT NULL
)
CHARSET utf8 COLLATE utf8_general_ci
ENGINE = InnoDB;

DROP table if exists products;
CREATE TABLE products
(
	product_id		INT				PRIMARY KEY		AUTO_INCREMENT,
	product_name	VARCHAR(45)		NOT NULL        UNIQUE
)
CHARSET utf8 COLLATE utf8_general_ci
ENGINE = InnoDB;

DROP table if exists downloads;
CREATE TABLE downloads
(
	download_id		INT				PRIMARY KEY		AUTO_INCREMENT,
	user_id			INT				REFERENCES		users (user_id),
	download_date	DATETIME		NOT NULL,
	filename		VARCHAR(50)		NOT NULL        UNIQUE,
	product_id		INT				REFERENCES		products (product_id)
)
CHARSET utf8 COLLATE utf8_general_ci
ENGINE = InnoDB;

CREATE INDEX downloads_download_date_ix
ON downloads (download_date);