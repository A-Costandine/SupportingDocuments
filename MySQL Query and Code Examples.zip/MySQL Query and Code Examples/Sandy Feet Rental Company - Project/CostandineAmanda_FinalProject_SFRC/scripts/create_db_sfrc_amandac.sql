-- *************************************************************
-- This script creates the sfrc_amandac database
-- *************************************************************

-- create the database
DROP DATABASE IF EXISTS sfrc_amandac;
CREATE DATABASE sfrc_amandac;

-- select the database
USE sfrc_amandac;


-- create the tables

DROP TABLE if exists clients;

CREATE TABLE clients
(
  client_id			INT(3) ZEROFILL NOT NULL	AUTO_INCREMENT,
  first_name		VARCHAR(25) 	NOT NULL,
  last_name         VARCHAR(25)		NOT NULL,
  address_1			VARCHAR(50)		NOT NULL,
  address_2			VARCHAR(50),
  city				VARCHAR(50)		NOT NULL,
  state				CHAR(2)			NOT NULL,
  zip_code			VARCHAR(10)		NOT NULL,
  phone				VARCHAR(13)		NOT NULL,
  email				VARCHAR(50),
  CONSTRAINT clients_pk
	PRIMARY KEY (client_id)
);

DROP TABLE if exists owners;

CREATE TABLE owners
(
  owner_id			INT(3) ZEROFILL NOT NULL	AUTO_INCREMENT,
  first_name		VARCHAR(25) 	NOT NULL,
  last_name         VARCHAR(25)		NOT NULL,
  address_1			VARCHAR(50)		NOT NULL,
  address_2			VARCHAR(50),
  city				VARCHAR(50)		NOT NULL,
  state				CHAR(2)			NOT NULL,
  zip_code			VARCHAR(10)		NOT NULL,
  phone				VARCHAR(13)		NOT NULL,
  email				VARCHAR(50),
  CONSTRAINT owners_pk 
	PRIMARY KEY (owner_id)
);

DROP TABLE if exists rates;

CREATE TABLE rates
(
  property_type			VARCHAR(25)		NOT NULL	UNIQUE,
  1_01_to_3_31			DECIMAL(9,2)	NOT NULL,
  4_01_to_5_31			DECIMAL(9,2)	NOT NULL,
  6_01_to_8_31			DECIMAL(9,2)	NOT NULL,
  9_01_to_10_31			DECIMAL(9,2)	NOT NULL,
  11_01_to_12_31		DECIMAL(9,2)	NOT NULL,
  CONSTRAINT rates_pk
	PRIMARY KEY (property_type)
);

DROP TABLE if exists properties;

CREATE TABLE properties
(
  property_id		INT(3) ZEROFILL NOT NULL	AUTO_INCREMENT,
  owner_id			INT(3) ZEROFILL NOT NULL,
  property_type		VARCHAR(25)		NOT NULL,
  building			VARCHAR(25)		NOT NULL,
  condo_number		VARCHAR(5)		NOT NULL,
  view_type			VARCHAR(25)		NOT NULL,
  bedrooms			INT(1)			NOT NULL,
  pets				VARCHAR(3)		NOT NULL,
  internet			VARCHAR(3)		NOT NULL,
  CONSTRAINT properties_pk
	PRIMARY KEY (property_id),
  CONSTRAINT properties_fk_owners
	FOREIGN KEY (owner_id)
	REFERENCES owners (owner_id)
	ON UPDATE CASCADE,
  CONSTRAINT properties_fk_rates
	FOREIGN KEY (property_type)
	REFERENCES rates (property_type)
	ON UPDATE CASCADE
);

DROP TABLE if exists transactions;

CREATE TABLE transactions
(
  transaction_id    INT(3) ZEROFILL NOT NULL AUTO_INCREMENT,
  property_id		INT(3) ZEROFILL	NOT NULL,
  client_id			INT(3) ZEROFILL NOT NULL,
  arrive_date		DATE			NOT NULL,
  depart_date		DATE			NOT NULL,
  rental_fee		DECIMAL(9,2)	NOT NULL,
  rental_deposit	DECIMAL(9,2)	NOT NULL,
  cleaning_fee		DECIMAL(9,2)	NOT NULL,
  pet_deposit		DECIMAL(9,2)	NOT NULL,
  pet_type			CHAR(3),
  payment_type		VARCHAR(25)		NOT NULL,
  CONSTRAINT transactions_pk
	PRIMARY KEY (transaction_id),
  CONSTRAINT transactions_fk_properties
	FOREIGN KEY (property_id)
	REFERENCES properties (property_id)
	ON UPDATE CASCADE,
  CONSTRAINT transactions_fk_clients
	FOREIGN KEY (client_id)
	REFERENCES clients (client_id)
	ON UPDATE CASCADE
);