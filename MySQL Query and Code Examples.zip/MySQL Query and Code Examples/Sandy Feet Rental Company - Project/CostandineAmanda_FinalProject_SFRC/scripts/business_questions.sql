--1
--main query
SELECT property_type, ROUND(((1_01_to_3_31 + 4_01_to_5_31 + 6_01_to_8_31 + 9_01_to_10_31 + 11_01_to_12_31) / 5) ,2) AS average_rate
FROM rates
GROUP BY property_type ASC;
--view
CREATE OR REPLACE VIEW View1_AverageRate AS
SELECT property_type, ROUND(((1_01_to_3_31 + 4_01_to_5_31 + 6_01_to_8_31 + 9_01_to_10_31 + 11_01_to_12_31) / 5) ,2) AS average_rate
FROM rates
GROUP BY property_type ASC;

--2
--main query
SELECT p.property_id, p.building, p.condo_number, o.first_name, o.last_name, o.address_1, o.city, o.state, o.zip_code, o.phone, o.email 
FROM properties p JOIN owners o USING(owner_id) 
WHERE NOT EXISTS
	(SELECT *
	 FROM transactions
	 WHERE property_id = p.property_id)
GROUP BY p.property_id ASC;
--view
CREATE OR REPLACE VIEW View2_UnrentedProperties AS
SELECT p.property_id, p.building, p.condo_number, o.first_name, o.last_name, o.address_1, o.city, o.state, o.zip_code, o.phone, o.email 
FROM properties p JOIN owners o USING(owner_id) 
WHERE NOT EXISTS
	(SELECT *
	 FROM transactions
	 WHERE property_id = p.property_id)
GROUP BY p.property_id ASC;

--3
--main query
SELECT transaction_id, arrive_date, depart_date, DATEDIFF(depart_date, arrive_date) AS days_rented 
FROM transactions
GROUP BY transaction_id ASC;
--view
CREATE OR REPLACE VIEW View3_DaysRented AS
SELECT transaction_id, arrive_date, depart_date, DATEDIFF(depart_date, arrive_date) AS days_rented 
FROM transactions
GROUP BY transaction_id ASC;

--4
--main query
SELECT c.client_id, c.first_name, c.last_name, COUNT(t.client_id) AS times_rented 
FROM clients c JOIN transactions t USING(client_id) 
GROUP BY c.client_id
HAVING COUNT(t.client_id) > 1
ORDER BY COUNT(t.client_id) DESC;
--view
CREATE OR REPLACE VIEW View4_FrequentRenters AS
SELECT c.client_id, c.first_name, c.last_name, COUNT(t.client_id) AS times_rented 
FROM clients c JOIN transactions t USING(client_id) 
GROUP BY c.client_id
HAVING COUNT(t.client_id) > 1
ORDER BY COUNT(t.client_id) DESC;

--5
--main query
SELECT c.client_id, c.first_name, c.last_name, c.address_1, c.address_2, c.city, c.state, c.zip_code
FROM clients c JOIN transactions t USING(client_id) 
WHERE EXTRACT(YEAR FROM t.arrive_date) = "2015"
GROUP BY c.client_id ASC;
--view
CREATE OR REPLACE VIEW View5_2015Renters AS
SELECT c.client_id, c.first_name, c.last_name, c.address_1, c.address_2, c.city, c.state, c.zip_code
FROM clients c JOIN transactions t USING(client_id) 
WHERE EXTRACT(YEAR FROM t.arrive_date) = "2015"
GROUP BY c.client_id ASC;

--6
--main query
SELECT property_type, 1_01_to_3_31, ROUND((1_01_to_3_31 + (1_01_to_3_31 * .06)), 2) AS 'Range 1 6% Increase', 4_01_to_5_31, ROUND((4_01_to_5_31 + (4_01_to_5_31 * .06)), 2) AS 'Range 2 6% Increase', 6_01_to_8_31, ROUND((6_01_to_8_31 + (6_01_to_8_31 * .06)), 2) AS 'Range 3 6% Increase', 9_01_to_10_31, ROUND((9_01_to_10_31 + (9_01_to_10_31 * .06)), 2) AS 'Range 4 6% Increase', 11_01_to_12_31, ROUND((11_01_to_12_31 + (11_01_to_12_31 * .06)), 2) AS 'Range 5 6% Increase' 
FROM rates
WHERE property_type = "SandsOV2BR" OR property_type = "SandsOV3BR"
ORDER BY property_type;
--view
CREATE OR REPLACE VIEW View6_IncreasedRates AS
SELECT property_type, 1_01_to_3_31, ROUND((1_01_to_3_31 + (1_01_to_3_31 * .06)), 2) AS 'Range 1 6% Increase', 4_01_to_5_31, ROUND((4_01_to_5_31 + (4_01_to_5_31 * .06)), 2) AS 'Range 2 6% Increase', 6_01_to_8_31, ROUND((6_01_to_8_31 + (6_01_to_8_31 * .06)), 2) AS 'Range 3 6% Increase', 9_01_to_10_31, ROUND((9_01_to_10_31 + (9_01_to_10_31 * .06)), 2) AS 'Range 4 6% Increase', 11_01_to_12_31, ROUND((11_01_to_12_31 + (11_01_to_12_31 * .06)), 2) AS 'Range 5 6% Increase' 
FROM rates
WHERE property_type = "SandsOV2BR" OR property_type = "SandsOV3BR"
ORDER BY property_type;

--7
--main query
SELECT EXTRACT(YEAR FROM arrive_date) AS year, property_id, SUM(rental_fee) AS rental_fee, SUM(cleaning_fee) AS cleaning_fee, SUM(pet_deposit) AS pet_deposit, (SUM(rental_fee) + SUM(cleaning_fee) + SUM(pet_deposit)) AS total_collected, ROUND(((SUM(rental_fee) * .25) + SUM(cleaning_fee) + SUM(pet_deposit)), 2) AS sfrc_fees, ROUND((SUM(rental_fee) - (SUM(rental_fee) * .25)), 2) AS owner_amounts 
FROM transactions
GROUP BY EXTRACT(YEAR FROM arrive_date) ASC, property_id ASC WITH ROLLUP;
--view
CREATE OR REPLACE VIEW View7_Totals AS
SELECT EXTRACT(YEAR FROM arrive_date) AS year, property_id, SUM(rental_fee) AS rental_fee, SUM(cleaning_fee) AS cleaning_fee, SUM(pet_deposit) AS pet_deposit, (SUM(rental_fee) + SUM(cleaning_fee) + SUM(pet_deposit)) AS total_collected, ROUND(((SUM(rental_fee) * .25) + SUM(cleaning_fee) + SUM(pet_deposit)), 2) AS sfrc_fees, ROUND((SUM(rental_fee) - (SUM(rental_fee) * .25)), 2) AS owner_amounts 
FROM transactions
GROUP BY EXTRACT(YEAR FROM arrive_date) ASC, property_id ASC WITH ROLLUP;

--8
--main query
SELECT payment_type, SUM(rental_fee) AS rental_fee, SUM(cleaning_fee) AS cleaning_fee, SUM(pet_deposit) AS pet_deposit, (SUM(rental_fee) + SUM(cleaning_fee) + SUM(pet_deposit)) AS total_collected
FROM transactions 
GROUP BY payment_type ASC WITH ROLLUP;
--view
CREATE OR REPLACE VIEW View8_TotalsByPaymentType AS
SELECT payment_type, SUM(rental_fee) AS rental_fee, SUM(cleaning_fee) AS cleaning_fee, SUM(pet_deposit) AS pet_deposit, (SUM(rental_fee) + SUM(cleaning_fee) + SUM(pet_deposit)) AS total_collected
FROM transactions 
GROUP BY payment_type ASC WITH ROLLUP;

--9
--question
--"What are the rental rate ranges for each owner's property in the Tides building?"
--main query
SELECT o.owner_id, o.first_name, o.last_name, p.property_id, p.property_type, r.1_01_to_3_31, r.4_01_to_5_31, r.6_01_to_8_31, r.9_01_to_10_31, r.11_01_to_12_31 
FROM owners o JOIN properties p USING (owner_id) JOIN rates r USING(property_type) 
WHERE p.property_type = "Tides2BR" OR p.property_type = "Tides3BR"
GROUP BY o.owner_id ASC;
--view
CREATE OR REPLACE VIEW View9_RentalRatesTidesByOwner AS
SELECT o.owner_id, o.first_name, o.last_name, p.property_id, p.property_type, r.1_01_to_3_31, r.4_01_to_5_31, r.6_01_to_8_31, r.9_01_to_10_31, r.11_01_to_12_31 
FROM owners o JOIN properties p USING (owner_id) JOIN rates r USING(property_type) 
WHERE p.property_type = "Tides2BR" OR p.property_type = "Tides3BR"
GROUP BY o.owner_id ASC;

--10
--question
--"What is the average rental rate for each owner's property in the Tides building?"
--main query
SELECT o.owner_id, o.first_name, o.last_name, p.property_id, p.property_type, ROUND(((r.1_01_to_3_31 + r.4_01_to_5_31 + r.6_01_to_8_31 + r.9_01_to_10_31 + r.11_01_to_12_31) / 5), 2) AS average_rate
FROM owners o JOIN properties p USING (owner_id) JOIN rates r USING(property_type) 
WHERE p.property_type = "Tides2BR" OR p.property_type = "Tides3BR"
GROUP BY o.owner_id ASC;
--view
CREATE OR REPLACE VIEW View10_AverageRatesTidesByOwner AS
SELECT o.owner_id, o.first_name, o.last_name, p.property_id, p.property_type, ROUND(((r.1_01_to_3_31 + r.4_01_to_5_31 + r.6_01_to_8_31 + r.9_01_to_10_31 + r.11_01_to_12_31) / 5), 2) AS average_rate
FROM owners o JOIN properties p USING (owner_id) JOIN rates r USING(property_type) 
WHERE p.property_type = "Tides2BR" OR p.property_type = "Tides3BR"
GROUP BY o.owner_id ASC;

--11
--main query
UPDATE properties 
SET internet = "Yes" 
WHERE internet = "No";
--view
CREATE OR REPLACE VIEW View11_UpdateInternet AS
SELECT * FROM properties;