--1a
SHOW COLUMNS FROM categories FROM mgs_amandac;
SHOW COLUMNS FROM products FROM mgs_amandac;
--1b
category_id

--2a
SELECT product_code, product_name, list_price, discount_percent FROM products;
--2b
SELECT product_code, product_name, list_price, discount_percent FROM products ORDER BY list_price DESC;

--3
SELECT CONCAT(last_name, ', ', first_name) AS 'Customers' FROM customers WHERE last_name > 'M' ORDER BY last_name ASC;

--4
SELECT product_name AS 'Name', list_price AS 'Price', date_added AS 'Date Added' FROM products WHERE list_price > 500 AND list_price < 2000 ORDER BY date_added DESC;

--5
SELECT product_name AS 'Name', list_price AS 'Price', discount_percent AS 'Discount Percent', ROUND((list_price * (discount_percent / 100)), 2) AS 'Discount Amount', ROUND((list_price - (list_price * (discount_percent / 100))), 2) AS 'Discount Price' FROM products ORDER BY ROUND((list_price - (list_price * (discount_percent / 100))), 2) DESC LIMIT 5;

--6
SELECT item_id AS 'Item', item_price AS 'Price', discount_amount AS 'Discount Amount', quantity AS 'Quantity', (item_price * quantity) AS 'Total Price', (discount_amount * quantity) AS 'Total Discount', ((item_price * quantity) - (discount_amount * quantity)) AS 'Total Price' FROM order_items WHERE ((item_price * quantity) - (discount_amount * quantity)) > 500 ORDER BY ((item_price * quantity) - (discount_amount * quantity)) DESC;

--7
SELECT order_id, order_date, ship_date FROM orders WHERE ship_date IS NULL;

--8
SELECT NOW() AS today_unformatted;

--9
SELECT 100 AS price, .07 AS tax_rate, (100 * .07) AS tax_amount, (100 + (100 * .07)) AS total;

--10
SELECT c.category_name AS category_name, p.product_name AS product_name, p.list_price AS list_price FROM categories c JOIN products p ON c.category_id = p.category_id ORDER BY c.category_name, p.product_name ASC;

SELECT c.category_name AS category_name, p.product_name AS product_name, p.list_price AS list_price FROM categories c JOIN products p USING(category_id) ORDER BY c.category_name, p.product_name ASC;

--11
SELECT c.first_name AS first_name, c.last_name AS last_name, a.line1 AS address, a.city AS city, a.state AS state, a.zip_code AS zip_code FROM customers c JOIN addresses a USING(customer_id) WHERE c.email_address = 'allan.sherwood@yahoo.com';

--12
SELECT c.first_name AS first_name, c.last_name AS last_name, a.line1 AS address, a.city AS city, a.state AS state, a.zip_code AS zip_code FROM customers c JOIN addresses a USING(customer_id) GROUP BY c.shipping_address_id;

--13
SELECT c.last_name AS last_name, c.first_name AS first_name, o.order_date AS order_date, p.product_name AS product_name, oi.item_price AS item_price, oi.discount_amount AS discount_amount, oi.quantity AS quantity FROM customers c JOIN orders o ON c.customer_id = o.customer_id JOIN order_items oi ON oi.order_id = o.order_id JOIN products p ON p.product_id = oi.product_id ORDER BY c.last_name, o.order_date, p.product_name;

--14
SELECT p1.product_name, p2.list_price FROM products p1 JOIN products p2 ON p1.product_id <> p2.product_id AND p1.list_price = p2.list_price ORDER BY p1.product_name;

--15
SELECT c.category_name, p.product_id FROM categories c LEFT JOIN products p ON c.category_id = p.category_id WHERE p.product_id IS NULL ORDER BY c.category_name;

--16
SELECT 'SHIPPED' AS ship_status, order_id, order_date FROM orders WHERE ship_date IS NOT NULL
UNION
SELECT 'NOT SHIPPED' AS ship_status, order_id, order_date FROM orders WHERE ship_date IS NULL ORDER BY order_date;

--17
SELECT COUNT(order_id) AS 'Number Of Orders', SUM(tax_amount) AS 'Amount of Taxes' FROM orders;

--18
SELECT c.category_name AS 'Category', COUNT(p.product_id) AS 'Amount of Products', MAX(p.list_price) AS 'Most Expensive Item' FROM categories c JOIN products p USING(category_id) GROUP BY c.category_name ORDER BY COUNT(p.product_id) DESC;

--19
SELECT c.email_address AS 'Email', (oi.item_price * oi.quantity) AS 'Order Cost', (oi.discount_amount * oi.quantity) AS 'Total Discount' FROM customers c JOIN orders o USING(customer_id) JOIN order_items oi USING(order_id) GROUP BY c.email_address ORDER BY (oi.item_price * oi.quantity) DESC;

--20
SELECT c.email_address AS 'Email', COUNT(o.order_id) AS 'Number of Orders', ((oi.item_price - oi.discount_amount) * oi.quantity) AS 'Total Orders Cost' 
FROM customers c JOIN orders o USING(customer_id) JOIN order_items oi USING(order_id) 
GROUP BY c.email_address 
HAVING COUNT(o.order_id) > 1 
ORDER BY ((oi.item_price - oi.discount_amount) * oi.quantity) DESC;

--21
SELECT c.email_address AS 'Email', COUNT(o.order_id) AS 'Number of Orders', ((oi.item_price - oi.discount_amount) * oi.quantity) AS 'Total Orders Cost' 
FROM customers c JOIN orders o USING(customer_id) JOIN order_items oi USING(order_id) 
WHERE ((oi.item_price - oi.discount_amount) * oi.quantity) > 400 
GROUP BY c.email_address 
ORDER BY ((oi.item_price - oi.discount_amount) * oi.quantity) DESC;

--22
SELECT p.product_name AS 'Product', SUM(((oi.item_price - oi.discount_amount) * oi.quantity)) AS 'Total Amount' FROM products p JOIN order_items oi USING(product_id) GROUP BY p.product_name ASC WITH ROLLUP;

--23
SELECT c.email_address AS 'Email', COUNT(DISTINCT oi.order_id) AS 'Number of Orders' FROM customers c JOIN orders o USING(customer_id) JOIN order_items oi USING(order_id) 
GROUP BY c.email_address 
HAVING COUNT(DISTINCT oi.order_id) > 1 
ORDER BY COUNT(DISTINCT oi.order_id) DESC;