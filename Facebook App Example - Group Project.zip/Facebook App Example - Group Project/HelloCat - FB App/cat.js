// Store the user's name and location as accessed via the Graph
var getName = "FB Graph Name",
    getTown = "FB Graph Location";

// Run the dialogue
function catInit() {
    $("#user").html("I don't know your name, Cat.");
    $("#cat").html("...");
    $("img").removeClass("catZoomIn").addClass("catZoomOut");
    
    
    $("#user").click(function cat() {
        $("#name").html(getName);
        $("#cat").html('Well I know yours, ' + getName).show();
        $("img").removeClass("catZoomOut").addClass("catZoomIn");
        
        console.log(getName);

        $("#user").html("That's pretty weird");
        $("html").css("height", "").css("height", "100%");
        
        $("#user").unbind("click", cat).bind("click", function weather() {
            $("#cat").html('UR funny. How\'s the weather in ' + getTown + '?');
            $("#user").html("Let's try this again").unbind("click", weather).bind("click", catInit);
    });
});
}

catInit();