/*
	Amanda L. Costandine
	Chapters 4-6
	Production Exam 2 - Future Value

	Suppose you have a certain amount of money in a savings account that earns compound monthly interest, and you want to calculate the amount you will have after a specific number of months. The formula, which is known as the future value formula, is:
	
	F = P * (1 + i)pow(t)
	
	The terms in the formula are as follows:
	•	F is the future value of the account after the specific time period
	•	P is the present value of the account
	•	i is the monthly interest rate
	•	t is the number of months
	
	Write a program that prompts the user to enter the accounts' present value, monthly interest rate, and the number of months that the money will be left in the account. The program should pass these values to a function named futureValue that returns the future value of the account after the specified number of months. The program should display the account's future value.
	
	
	Algorithm:

		•	Define function prototypes
		•	Set variables for input
		•	Declare purpose of program to user
		•	Prompt user for input
		•	Validate input
		•	Call function to calculate future value
		•	Display input and future value to user
		•	End program
		•	Define functions outside of int main(below)
*/

//Program
#include <iostream>
#include <iomanip> //For output formatting
#include <cmath> //for pow function

using namespace std;

//Define funtion prototypes
double futureValue(double valueP, double rateInt, double numMonth);

int main()
{
	//Set variable for pause
	char ch;
	
	//Set variables for input and output
	double valueF, valueP, rateInt, numMonth;
	
	//Declare purpose of program to user
	cout << "Future Value Calculator" << endl;
	
	//Prompt user for present value of the account
	cout << "\nWhat is the amount currently in the account? $";
	cin >> valueP;
	
	//Validate valueP
	while (valueP <= 0.00) {
		cout << "\nThat is not a valid amount. Amount must be a positive number and not $0.00" << endl;
		cout << "What is the amount currently in the account? $";
		cin >> valueP;
	} //End while validate valueP
	
	//Prompt user for the monthly interest rate
	cout << "\nWhat is your monthly interest rate (ex. 40% = 40) ";
	cin >> rateInt;
	
	//Validate rateInt
	while (rateInt <= 0.00) {
		cout << "\nThat is not a valid interest rate. Amount must be a positive number and not 0.00" << endl;
		cout << "What is your monthly interest rate (ex. 40% = 40) ";
		cin >> rateInt;
	} //End while validate rateInt
	
	//Prompt user for the number of months they wish to calculate for
	cout << "\nHow many months will the amount stay in the account? ";
	cin >> numMonth;
	
	//Validate numMonth
	while (numMonth < 1.00) {
		cout << "\nThat is not a valid number of months. Number of months muct be at least 1" << endl;
		cout << "How many months will the amount stay in the account? ";
		cin >> numMonth;
	} //End while validate numMonth
	
	//Call function to calculate future value
	valueF = futureValue(valueP, rateInt, numMonth);
	
	//Display results to the user
	cout << "\n\nAmount in account:                $" << setprecision(2) << fixed << valueP << endl;
	cout << "Monthly interest rate:             " << setprecision(1) << fixed << rateInt << "%" << endl;
	cout << "Number of months:                  " << setprecision(0) << fixed << numMonth << endl;
	cout << "-----------------------------------------" << endl;
	cout << "Future value of account:          $" << setprecision(2) << fixed << valueF << endl;
	
	//Pauses program so user can view data
	cout << "\n\nPress enter to exit." << endl;
	cin.get(ch);
	
	//End program
	return 0;
}

//Define functions outside of int main(below)
//Function for calculating future value
double futureValue(double valueP, double rateInt, double numMonth)
{
	return valueP * pow((1 + (rateInt / 100)), numMonth);
} //End function
