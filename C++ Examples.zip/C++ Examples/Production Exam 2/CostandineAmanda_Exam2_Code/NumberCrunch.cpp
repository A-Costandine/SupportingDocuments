/*
	Amanda L. Costandine
	Chapters 4-6
	Production Exam 2 - Number Crunch

	Write a program to do the following based on the NumberCrunch.txt file. Tell the user how many numbers are in the file, the sum of the numbers, and the average of the numbers.
	
	
	Algorithm:

		�	Display purpose to user and notify of file open/start
		�	Open file for read mode
		�	Count how many numbers are in file and sum the numbers in the file
		�	Average the numbers in the file
		�	Notify user of close file
		�	Close file
		�	Display results to user
		�	End program
*/

//Program
#include <fstream>
#include <iostream>

using namespace std;

int main()
{
	//Set variable for pause
	char ch;
	
	//Set variables for counter, sum and average and numbers from file
	int numCount = 0;
	int numSum = 0;
	int numAverage = 0;
	int numFile = 0;
	
	//Declare program purpose to user
	cout << "Count how many numbers are in NumberCrunch.txt and give the sum and average of those numbers" << endl;
	
	//Notify user of file opening
	cout << "\nOpening File NumberCrunch.txt..." << endl;
	
	//Notify user of file reading
	cout << "\nReading File NumberCrunch.txt..." << endl;
	
	//Open file for read mode
	ifstream inputfile;
	inputfile.open("NumberCrunch.txt");
	
	//Checks if file opened properly, then execute rest of program. If file not opened correctly, displays error and ends program
	if(inputfile) {
	
		//Count how many numbers are in file and sum numbers in file
		while(inputfile >> numFile) {
			numSum = numFile + numSum;
			numCount++;
		} //End while
	
		//Average the numbers in the file
		numAverage = numSum / numCount;
	
		//Notify user of closing file
		cout << "\nClosing file NumberCrunch.txt..." << endl;
	
		//Close file
		inputfile.close();
	
		//Display results to user
		cout << "\n\nThe Count of numbers in NumberCrunch.txt are:       " << numCount << endl;
		cout << "The Sum of the numbers in NumberCrunch.txt are:     " << numSum << endl;
		cout << "The Average of the numbers in NumberCrunch.txt are: " << numAverage << endl;
	}
	else {
		cout << "\nError opening file..." << endl;
	} //End if-else file read open
	
	//Pauses program so user can view data
	cout << "\n\nPress enter to exit." << endl;
	cin.get(ch);
	
	//End program
	return 0;
}