/*
	Amanda L. Costandine
	Chapters 4-6
	Production Exam 2 - Guessing Game

	Write a program that generates a random number and asks the user to guess the number. The program should display �too high, go lower� or �too low, go higher� until the user guesses the correct number. Keep a count of the number of guesses. When the user provides the correct number, let them know the number of guesses.
	
	
	Algorithm:
		�	Set constant variables for random number constraints
		�	Set variables for random number, input and the guess counter
		�	Seed the random number generator
		�	Generate the random number
		�	Declare program purpose to user
		�	Prompt for input
		�	Validate input
		�	Set a loop to keep looping until correct answer is reached
		�	Test variable to see if it is too high or too low then ask for imput again
		�	Keep count of number of tries
		�	If/When correct number is guessed display congratulatory message
		�	Display number of guesses it took to find answer
		�	Pause program so user can view data
		�	End program
*/

//Program
#include <iostream> //For in out stream
#include <cstdlib> //For rand and srand
#include <ctime> //For time function

using namespace std;

int main()
{
	//Set constant variables for random number constraints
	const int MIN_VALUE = 1; //Min number for random number
	const int MAX_VALUE = 10; //Max number for random number
	
	//Set variables for random number, input and the guess counter
	int randNum, guessNum, countNum;
	
	//Set counter to 0
	countNum = 0;
	
	//Set variable for pause
	char ch;
	
	//Get system time for proper random numbers
	unsigned seed = time(0);
	
	//Seed the random number generator
	srand(seed);
	
	//Generate the random number
	randNum = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
	
	//Declare program purpose to user and prompt for input
	cout << "Guessing Game" << endl;
	cout << "\nGuess a number between 1 and 10 :";
	cin >> guessNum;
	
	//Validate guessNum
	while ( guessNum < 1 || guessNum > 10) {
		cout << "\nThat is not a valid entry." << endl;
		cout << "Guess a number between 1 and 100 :";
		cin >> guessNum;
	}
	
	//Sets a loop for guessing until the correct answer is reached
	while (guessNum < randNum || guessNum > randNum) {
		//Tests guessNum to see if it is too high or too low then asks for imput again
		if (guessNum < randNum) {
			cout << "\nToo low, go higher" << endl;
			cout << "Guess a number between 1 and 100 :";
			cin >> guessNum;
			countNum++;
			
		}
		else if (guessNum > randNum) {
			cout << "\nToo high, go lower" << endl;
			cout << "Guess a number between 1 and 100 :";
			cin >> guessNum;
			countNum++;
		}
	} //End while loop
	
	
	//If randNum is guessed correctly displays congratulatory message
	if (guessNum == randNum) {
		cout << "\nYou guessed right!" << endl;
		countNum++;
	}
	
	//Displays number of guesses it took to find answer
	cout << "It took you " << countNum << " tries to guess the correct number." << endl;
	
	//Pauses program so user can view data
	cout << "\n\nPress enter to exit." << endl;
	cin.get(ch);
	
	//End program
	return 0;
}