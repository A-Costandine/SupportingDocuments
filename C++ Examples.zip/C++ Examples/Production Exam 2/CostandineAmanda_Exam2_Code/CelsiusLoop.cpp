/*
	Amanda L. Costandine
	Chapters 4-6
	Production Exam 2 - Celsius Loop

	The formula for converting a temperature from Fahrenheit to Celsius is:
	
	C = 5/9(F - 32)
	
	Where F is the Fahrenheit temperature and C is the Celsius temperature. Write a function named celsius that accepts a Fahrenheit temperature as an argument. The function should return the temperature, converted to Celsius. Demonstrate the function by calling it in a loop that displays a table of the Fahrenheit 0 through 20 and their Celsius equivalents.
	
	
	Algorithm:
		�	Set constant variables for random number constraints
		�	Set variables for random number, input and the guess counter
		�	Seed the random number generator
		�	Generate the random number
		�	Declare program purpose to user
		�	Prompt for input
		�	Validate input
		�	Set a loop to keep looping until correct answer is reached
		�	Test variable to see if it is too high or too low then ask for imput again
		�	Keep count of number of tries
		�	If/When correct number is guessed display congratulatory message
		�	Display number of guesses it took to find answer
		�	Pause program so user can view data
		�	End program
*/

//Program
#include <iostream> //For in out stream
#include <iomanip> //For output formatting

using namespace std;

//Define function protoypes
double celsius(double divide, double tempF, double minus);

int main()
{
	
	//Set variables for temperatures
	double tempC = 0;
	double tempF = 0;
	double divide = 0.55;
	double minus = 32;
	
	//Set variable for pause
	char ch;
	
	//Declare program purpose to user
	cout << "Fahrenheit Temperature Celsius Converstion Table\n" << endl;
	cout << "Temperature in Fahrenheit ---------- Temperature in Celsius\n" << endl;

	//loop to iterate table and call function here
	for (int i = 0; i < 20; i++) {
		tempF++;
		//call function
		tempC = celsius(divide, tempF, minus);
		//Display tempF and tempC
		cout << "                       " << setprecision(0) << fixed << tempF << " ---------- " << setprecision(2) << fixed << tempC << endl;
	}
	
	//Pauses program so user can view data
	cout << "\n\nPress enter to exit." << endl;
	cin.get(ch);
	
	//End program
	return 0;
}

//Function to convert Fahrenheit to Celsius
double celsius(double divide, double tempF, double minus)
{
	return (divide * tempF) - (divide * minus);
} //End function