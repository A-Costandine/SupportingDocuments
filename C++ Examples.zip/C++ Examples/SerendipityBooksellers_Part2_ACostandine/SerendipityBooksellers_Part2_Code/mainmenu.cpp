/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - mainmenu.cpp
*/

//Header files
#include "bookinfo.h"
#include "cashier.h"
#include "invmenu.h"
#include "reports.h"

//Libraries
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

//Set global variables
const int SIZE = 20;

//Arrays

//Array bookISBN
string bookISBN[SIZE];

//Array bookTitle
string bookTitle[SIZE];

//Array bookAuthor
string bookAuthor[SIZE];

//Array bookPublisher
string bookPublisher[SIZE];

//Array dateAdded
string dateAdded[SIZE];

//Array qtyOnHand
int qtyOnHand[SIZE];

//Array wholesalePrice
double wholesalePrice[SIZE];

//Array retailPricw
double retailPrice[SIZE];

int main()
{
	
	//Set varibles
	int choice;
	
	do {	
		//Display title and menu
		cout << "\n\n";
		cout << "	\t\Serendipity Booksellers\n"
			<< "      			Main Menu\n\n"
			<< "		1. Cashier Module\n"
			<< "		2. Inventory Database Module\n"
			<< "		3. Report Module\n"
			<< "		4. Exit\n\n";
		 
		 
		cout << "		Enter Your Choice: ";
		cin >> choice;

		//Validate input
		while ( choice < 1 || choice > 4 ){
			cout << "	\nPlease enter a number in the range of 1-4\n\n";
			cout << "		Enter Your Choice: ";
			cin >> choice;
			cout << "\n";
		} //End while
	
		//Switch statement for menu
		switch (choice)
		{
			case 1: cashier();
					break;
			case 2: invMenu();
					break;
			case 3: reports();
					break;
			case 4: cout << "		You selected menu item 4 - Exit.\n";
					break;
			default: cout << "Something went wrong. Try again.\n";
		} //End switch
		
	} while ( choice != 4 ); //End do-while
	
   //End program
   return 0;
   
} //End program main