/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - invmenu.h
*/

#ifndef INVMENU_H
#define INVMENU_H

void invMenu();
void lookUpBook();
void addBook();
void editBook();
void deleteBook();

#endif