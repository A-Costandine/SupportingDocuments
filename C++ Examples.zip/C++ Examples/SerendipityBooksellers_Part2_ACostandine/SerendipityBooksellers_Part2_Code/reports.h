/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - reports.h
*/

#ifndef REPORTS_H
#define REPORTS_H

void reports();
void repListing();
void repWholesale();
void repRetail();
void repQty();
void repCost();
void repAge();

#endif