/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - cashier.cpp
*/

//Header file
#include "cashier.h"

//Libraries
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

void cashier()
{
	
	//Set variables
	string saleDate;
	string bookISBN;
	string bookTitle;
	string yn2 = "Y";
	int saleQuantity;
	double unitPrice, saleSubtotal, saleTax, saleTotal;
	double sales_tax = 0.06;
	
	//Initialized do-while to loop main program if user wishes to enter more than one transaction
	do {
	
		//Display cashier module title
		cout << "\n\n";
		cout << "  Serendipity Book Sellers\n";
		cout << "    Cashier Module\n\n";
		cin.ignore();
	
		//Prompt for saleDate
		cout << "    Date: ";
		getline(cin, saleDate);
	
		//Prompt for saleQuantity
		cout << "    Quantity of Book: ";
		cin >> saleQuantity;
		cin.ignore();
	
		//Prompt for ISBN
		cout << "    ISBN: ";
		getline(cin, bookISBN);
	
		//Prompt for bookTitle
		cout << "    Title: ";
		getline(cin, bookTitle);
	
		//Prompt for unitPrice
		cout << "    Price: $";
		cin >> unitPrice;
		cout << "\n\n";
	
		
			//Calculate totals
			saleSubtotal = ( saleQuantity * unitPrice );
			saleTax = ( saleSubtotal * sales_tax );
			saleTotal = ( saleSubtotal + saleTax );
		
			//Sales Slip Display
			//Display title
			cout << "\n\n\n\n";
			cout << "	Serendipity Book Sellers\n\n\n";
	
			//Display date
			cout << "	Date: " << saleDate;
			cout << "\n\n\n";
	
			//Display book info titles
			cout << "	Qty	ISBN		Title			Price		Total";
			cout << "\n";
	
			//Display divider
			cout << "	__________________________________________________________________________";
			cout << "\n";
		
			//Display book info entered
			cout << "	" <<  saleQuantity << "	" <<  bookISBN << "	" << bookTitle << "	$" << setw(6) << setprecision(2) << fixed << unitPrice << "		$" << setw(6) << setprecision(2) << fixed << saleSubtotal;
			cout << "\n\n\n";
	
			//Display totals
			cout << "			Subtotal					$" << setw(6) << setprecision(2) << fixed << saleSubtotal;
			cout << "\n";
			cout << "			Tax						$" << setw(6) << setprecision(2) << fixed << saleTax;
			cout << "\n";
			cout << "			Total						$" << setw(6) << setprecision(2) << fixed << saleTotal;
			cout << "\n\n\n";
	
			//Display bottom message
			cout << "	Thank You for Shopping at Serendipity!\n\n\n";
			cin.ignore();
			
			//Asks user if they would like to process another transaction
			cout << "    Would you like to process another transaction? Enter Y to continue or N to exit: ";
			//cin.ignore();
			getline(cin, yn2);
			
	} while (yn2 == "Y" || yn2 == "y"); //End do-while main program loop
			
} //End program cashier