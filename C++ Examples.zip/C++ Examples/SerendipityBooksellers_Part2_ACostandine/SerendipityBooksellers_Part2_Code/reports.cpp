/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - reports.cpp
*/

//Header file
#include "reports.h"

//Libraries
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

void reports()
{

	//Set varibles
	int choice;
	
	do {
	
		//Display title and menu
		cout << "\n\n";
		cout << "	\t\Serendipity Booksellers\n"
			<< "      			Reports\n\n"
			<< "		1. Inventory Listing\n"
			<< "		2. Inventory Wholesale Value\n"
			<< "		3. Inventory Retail Value\n"
			<< "		4. Listing by Quantity\n"
			<< "		5. Listing by Cost\n"
			<< "		6. Listing by Age\n"
			<< "		7. Return to Main Menu\n\n";
		 
		 
		cout << "		Enter Your Choice: ";
		cin >> choice;
	
		//Validate input
		while ( choice < 1 || choice > 7 ){
			cout << "	\nPlease enter a number in the range of 1-7\n\n";
			cout << "		Enter Your Choice: ";
			cin >> choice;
			cout << "\n";
		} //End while
	
		//Switch statement for menu
		switch (choice)
		{
			case 1: repListing();
					break;
			case 2: repWholesale();
					break;
			case 3: repRetail();
					break;
			case 4: repQty();
					break;
			case 5: repCost();
					break;
			case 6: repAge();
					break;
			case 7: cout << "		You selected menu item 7 - Return to Main Menu.\n";
					break;
			default: cout << "		Something went wrong. Try again.\n";
		} //End switch
		
	} while ( choice != 7 ); //End do-while
	
} //End program reports

//Function definitions

//Function repListing
void repListing()
{
	cout << "		You selected menu item 1 - Inventory Listing.\n";
}

//Function repWholesale
void repWholesale()
{
	cout << "		You selected menu item 2 - Inventory Wholesale Value.\n";
}

//Function repRetail
void repRetail()
{
	cout << "		You selected menu item 3 - Inventory Retail Value.\n";
}

//Function repQty
void repQty()
{
	cout << "		You selected menu item 4 - Listing by Quantity.\n";
}

//Function repCost
void repCost()
{
	cout << "		You selected menu item 5 - Listing by Cost.\n";
}

//Function repAge
void repAge()
{
	cout << "		You selected menu item 6 - Listing by Age.\n";
}