/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - cashier.h
*/

#ifndef CASHIER_H
#define CASHIER_H

void cashier();

#endif