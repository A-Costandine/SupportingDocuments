/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - bookinfo.h
*/

#ifndef BOOKINFO_H
#define BOOKINFO_H

#include <string>

using namespace std;

void bookInfo(string, string, string, string, string, int, double, double);

#endif