/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - invmenu.cpp
*/

//Header file
#include "invmenu.h"

//Libraries
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

void invMenu()
{
	
	//Set varibles
	int choice;
	
	do {
	
		//Display title and menu
		cout << "\n\n";
		cout << "	\t\Serendipity Booksellers\n"
			<< "		  Inventory Database\n\n"
			<< "		1. Look Up a Book\n"
			<< "		2. Add a Book\n"
			<< "		3. Edit a Book's Record\n"
			<< "		4. Delete a Book\n"
			<< "		5. Return to the Main Menu\n\n";
		 
		cout << "		Enter Your Choice: ";
		cin >> choice;
	
		//Validate input
		while ( choice < 1 || choice > 5 ){
			cout << "	\nPlease enter a number in the range of 1-5\n\n";
			cout << "		Enter Your Choice: ";
			cin >> choice;
			cout << "\n";
		} //End while
	
		//Switch statement for menu
		switch (choice)
		{
			case 1: lookUpBook();
					break;
			case 2: addBook();
					break;
			case 3: editBook();
					break;
			case 4: deleteBook();
					break;
			case 5: cout << "		You selected menu item 5 - Return to Main Menu.\n";
					break;
			default: cout << "		Something went wrong. Try again.\n";
		} //End switch
		
	} while ( choice != 5 ); //End do-while
	
} //End program invMenu

//Function definitions

//Function lookUpbook
void lookUpBook()
{
	cout << "		You selected menu item 1 - Look Up a Book.\n";
}

//Function addBook
void addBook()
{
	cout << "		You selected menu item 2 - Add a Book.\n";
}

//Function editBook
void editBook()
{
	cout << "		You selected menu item 3 - Delete a Book.\n";
}

//Function deleteBook
void deleteBook()
{
	cout << "		You selected menu item 4 - Edit a Book's Record.\n";
}