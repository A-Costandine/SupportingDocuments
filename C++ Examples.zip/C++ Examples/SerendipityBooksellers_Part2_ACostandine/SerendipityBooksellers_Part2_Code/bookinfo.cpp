/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 2 - bookinfo.cpp
*/

//Header file
#include "bookinfo.h"

//Libraries
#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

void bookInfo(string bookISBN, string bookTitle, string bookAuthor, string bookPublisher, string dateAdded, int qtyOnHand, double wholesalePrice, double retailPrice)
{

	//Display title
	cout << "\n\n";
	cout << "		\t\Serendipity Booksellers\n"
		 << "			    Book Information\n\n\n";
		 
	//Display book info
	cout << "	ISBN: " << bookISBN << endl;
	cout << "	Title: " << bookTitle << endl;
	cout << "	Author: " << bookAuthor << endl;
	cout << "	Publisher: " << bookPublisher << endl;
	cout << "	Date Added: " << dateAdded << endl;
	cout << "	Quantity-On-Hand: " << qtyOnHand << endl;
	cout << "	Wholesale Cost: " << wholesalePrice << endl;
	cout << "	Retail Price: " << retailPrice << endl;
	cout << "\n\n";
	
} //End program bookInfo