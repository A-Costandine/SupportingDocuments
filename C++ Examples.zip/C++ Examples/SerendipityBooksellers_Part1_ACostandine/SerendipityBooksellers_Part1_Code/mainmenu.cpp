/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 1 - mainmenu.cpp
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{
	//Set variable for pause
	char ch;
	
	//Set varibles
	int choice;
	
	//Display title and menu
	cout << "\n\n";
	cout << "	\t\Serendipity Booksellers\n"
		 << "      			Main Menu\n\n"
		 << "		1. Cashier Module\n"
		 << "		2. Inventory Database Module\n"
		 << "		3. Report Module\n"
		 << "		4. Exit\n\n";
		 
		 
	cout << "		Enter Your Choice: ";
	cin >> choice;

	//Validate input
	while ( choice < 1 || choice > 4 ){
		cout << "	\nPlease enter a number in the range of 1-4\n\n";
		cout << "		Enter Your Choice: ";
		cin >> choice;
		cout << "\n";
	}
	
	//Switch statement for menu
	switch (choice)
	{
		case 1: cout << "		You selected menu item 1.\n";
				break;
		case 2: cout << "		You selected menu item 2.\n";
				break;
		case 3: cout << "		You selected menu item 3.\n";
				break;
		case 4: cout << "		You selected menu item 4.\n";
				break;
		default: cout << "Something went wrong. Try again.";
	}

	//Pauses program so user can view data
	cout << "\n\nPress enter to exit." << endl;
	cin.get(ch);
	
   return 0;
} 