/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 1 - bookinfo.cpp
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{

	//Display title
	cout << "\n\n";
	cout << "		\t\Serendipity Booksellers\n"
		 << "			    Book Information\n\n\n";
		 
	//Display book info
	cout << "	ISBN: ";
	cout << "\n";
	cout << "	Title: ";
	cout << "\n";
	cout << "	Author: ";
	cout << "\n";
	cout << "	Publisher: ";
	cout << "\n";
	cout << "	Date Added: ";
	cout << "\n";
	cout << "	Quantity-On-Hand: ";
	cout << "\n";
	cout << "	Wholesale Cost: ";
	cout << "\n";
	cout << "	Retail Price: ";
	cout << "\n\n";

	
   return 0;
} 