/*
	Amanda L. Costandine
	CSC 134 YD1 Fall 2016
	Final
	Part 1 - cashier.cpp
*/

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

int main()
{

	//Set variable for pause
	char ch;
	
	//Set variables
	string saleDate;
	string bookISBN;
	string bookTitle;
	string yn;
	int saleQuantity;
	double unitPrice, saleSubtotal, saleTax, saleTotal;
	double sales_tax = 0.06;
	
	//Display cashier module title
	cout << "\n\n";
	cout << "  Serendipity Book Sellers\n";
	cout << "    Cashier Module\n\n";
	
	//Prompt for saleDate
	cout << "    Date: ";
	getline(cin, saleDate);
	
	//Prompt for saleQuantity
	cout << "    Quantity of Book: ";
	cin >> saleQuantity;
	cin.ignore();
	
	//Prompt for ISBN
	cout << "    ISBN: ";
	getline(cin, bookISBN);
	
	//Prompt for bookTitle
	cout << "    Title: ";
	getline(cin, bookTitle);
	
	//Prompt for unitPrice
	cout << "    Price: $";
	cin >> unitPrice;
	cout << "\n\n";
	
	//Pauses program so user can view data
	cout << "    If all entered is correct, press enter Y to continue or N to exit: ";
	cin.ignore();
	getline(cin, yn);
	
	if ( yn == "Y" || yn == "y" ){
		
		//Calculate totals
		saleSubtotal = ( saleQuantity * unitPrice );
		saleTax = ( saleSubtotal * sales_tax );
		saleTotal = ( saleSubtotal + saleTax );
		
		//Sales Slip Display
		//Display title
		cout << "\n\n\n\n";
		cout << "	Serendipity Book Sellers\n\n\n";
	
		//Display date
		cout << "	Date: " << saleDate;
		cout << "\n\n\n";
	
		//Display book info titles
		cout << "	Qty	ISBN		Title			Price		Total";
		cout << "\n";
	
		//Display divider
		cout << "	__________________________________________________________________________";
		cout << "\n";
		
		//Display book info entered
		cout << "	" <<  saleQuantity << "	" <<  bookISBN << "	" << bookTitle << "	$" << setw(6) << setprecision(2) << fixed << unitPrice << "		$" << setw(6) << setprecision(2) << fixed << saleSubtotal;
		cout << "\n\n\n";
	
		//Display totals
		cout << "			Subtotal					$" << setw(6) << setprecision(2) << fixed << saleSubtotal;
		cout << "\n";
		cout << "			Tax						$" << setw(6) << setprecision(2) << fixed << saleTax;
		cout << "\n";
		cout << "			Total						$" << setw(6) << setprecision(2) << fixed << saleTotal;
		cout << "\n\n\n";
	
		//Display bottom message
		cout << "	Thank You for Shopping at Serendipity!\n\n\n";
	
	}
	else {
		
		//End program
		return 0;
		
	} //End if-else
		
	//Pauses program so user can view data
	cout << "\n\n\n\n	Press enter to exit." << endl;
	cin.get(ch);
	
	//End program
	return 0;
		
} //End program int main