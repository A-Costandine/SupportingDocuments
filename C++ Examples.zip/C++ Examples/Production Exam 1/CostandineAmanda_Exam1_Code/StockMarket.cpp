/*
	Amanda L. Costandine
	Chapters 1-3
	Production Exam 1 - Stock Market
	
	
	Last month you purchased 1,000 shares at $45.50 per share. You paid the stockbroker 2% of the amount paid for the stock.

	Yesterday you sold all the stock at $56.90 per share. You paid the stockbroker 2% of the amount received for the sale.

	Write a program to display all information about the transaction. 

	Check Yourself: the purchase should have cost $46,410.00 ($45,500 for the shares plus $910 to the broker) and the sale amount would be $55,762 ($56,900 for the shares - $1,138 to the broker). Thus, you had a profit of $9,352.00.
	
	Algorithm:
		�	Set constant variables
		�	Set variables
		�	Calculate initial purchase
		�	Calculate broker share of initial purchase
		�	Calculate total initial purchase
		�	Calculate sale
		�	Calculate broker share of sale
		�	Calculate total sale
		�	Calculate profit
		�	Display initial purchase, initial purchase broker share, total initial purchase, sale, broker share of sale, total sale, and profit to user
		�	End program
*/

#include <iostream>
#include <iomanip> //For output formatting

using namespace std;

int main()
{
	//Set constant variables
	const double BROKER_CUT = 0.02;
	const double SHARES_AMOUNT = 1000;
	const double SHARES_BUY = 45.50;
	const double SHARES_SELL = 56.90;
	
	//Set variables for pauses
	char ch;
	
	//Set variables for calculations
	double amountBuy, amountBrokerBuy, amountTotalBuy, amountSell, amountBrokerSell, amountAfterBroker, amountProfit;
	
	//Calculate Total purchase amounts
	amountBuy = SHARES_AMOUNT * SHARES_BUY;
	amountBrokerBuy = amountBuy * BROKER_CUT;
	amountTotalBuy = amountBuy + amountBrokerBuy;
	
	//Calculate total sales amounts
	amountSell = SHARES_AMOUNT * SHARES_SELL;
	amountBrokerSell = amountSell * BROKER_CUT;
	amountAfterBroker = amountSell - amountBrokerSell;
	
	//Calculate profit
	amountProfit = amountAfterBroker - amountTotalBuy;
	
	//Display transaction amounts to user
	cout << "Your Recent Stock Transaction Fiscal Breakdown" << endl;
	cout << "\n\nShares Purchased: " << SHARES_AMOUNT << endl;
	
	//Purchase amounts
	cout << "\nPrice Per Share at Purchase: $" << setprecision(2) << fixed << SHARES_BUY << endl;
	cout << "Price of Purchase: $" << setprecision(2) << fixed << amountBuy << endl;
	cout << "Amount Paid to Broker: $" << setprecision(2) << fixed << amountBrokerBuy << endl;
	cout << "Total Paid for Purchase of Shares: $" << setprecision(2) << fixed << amountTotalBuy << endl;
	
	//Sale amounts
	cout << "\nPrice Per Share at Sale: $" << setprecision(2) << fixed << SHARES_SELL << endl;
	cout << "Price of Sale: $" << setprecision(2) << fixed << amountSell << endl;
	cout << "Amount Paid to Broker: $" << setprecision(2) << fixed << amountBrokerSell << endl;
	cout << "Amount of Sale After Broker Cut: $" << setprecision(2) << fixed << amountAfterBroker << endl;
	
	//Profit
	cout << "\n\nTotal Profit: $" << setprecision(2) << fixed << amountProfit << endl;
	
	//Pauses program until user can review information and wishes to exit
	cout << "\n\nPress enter to exit" << endl;
	cin.get(ch);
	
	//End program
	return 0;
}