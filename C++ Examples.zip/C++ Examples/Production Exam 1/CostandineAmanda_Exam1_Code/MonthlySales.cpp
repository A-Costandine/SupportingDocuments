/*
	Amanda L. Costandine
	Chapters 1-3
	Production Exam 1 - Monthly Sales
	
	
	A company must do a monthly report of sales and taxes (county and state). County tax is 2 percent and state tax is 4 percent� thus, total tax is 6 percent. Write a program which will ask the user for the year (four digits), month (spelled out), and the total amount of money collected for the month. 

	From the total amount collected, compute a breakdown of how was much sales, county tax, and state tax.

	Sample data: if total collected were $20,000, you would divide $20,000 by 1.06 (because the number includes 100% of the sales plus the 6% for taxes). You find that sales were $18,867.92, county taxes were $377.36, and state taxes were $754.72.
	
	Algorithm:
		�	Set constant variables
		�	Set variables
		�	Prompt user to input year
		�	Get year input from user
		�	Prompt user to input month
		�	Get month input from user
		�	Prompt user to input money collected
		�	Calculate county tax
		�	Calculate state tax
		�	Calculate amout that was sales
		�	Display year, month, money collected, county tax, state tax, and the amount that was sales to user
		�	End program
*/

#include <iostream>
#include <iomanip> //For output formatting
#include <string> //For string input/output

using namespace std;

int main()
{
	//Set constant variables
	const double STATE_TAX = 0.04;
	const double COUNTY_TAX = 0.02;
	const double SALES_FACTOR = 1.06;
	
	//Set variables for pauses
	char ch;
	
	//Set variables for input
	string year;
	string month;
	double amountCollected, amountSales, amountState, amountCounty;
	
	//Prompt user for input (Year, Month, Amount Collected)
	cout << "Please enter the year (yyyy)" << endl;
	cin >> year;
	cout << "\nPlease enter the month (name of month)" << endl;
	cin >> month;
	cout << "\nPlease enter the total dollar amount collected" << endl;
	cin >> amountCollected;
	
	//Calculate the breakdown of the amountCollected into amountSales, amountState, and amountCounty
	amountSales = amountCollected / SALES_FACTOR;
	amountState = amountSales * STATE_TAX;
	amountCounty = amountSales * COUNTY_TAX;
	
	//Display Year, Month, Amount Collected, Amount of Sales, Amount of State Tax, and Amount of County taxt to user
	cout << "\n\nThe fiscal breakdown for " << month << " of " << year << " is as follows:" << endl;
	cout << "\nTotal dollar amount collected: $" << setprecision(2) << fixed << amountCollected << endl;
	cout << "Total amount of sales: $" << setprecision(2) << fixed << amountSales << endl;
	cout << "Total amount of state sales tax: $" << setprecision(2) << fixed << amountState << endl;
	cout << "Total amount of county sales tax: $" << setprecision(2) << fixed << amountCounty << endl;
	cout << "\nPress enter to exit" << endl;
	cin.get(ch);
	
	//End program
	return 0;
}