/*
	Amanda L. Costandine
	Chapters 1-3
	Production Exam 1 - Addition Play
	
	
	You need to help your nephew with addition�. write a program to display two random numbers and NOT display the sum until the user presses Enter. This will give your nephew time to do the addition and then check himself with the solution.
	
	Algorithm:
		�	Set variables
		�	Create two random numbers
		�	Display random numbers
		�	Pause for enter input from user with prompt
		�	Calculate sum
		�	Display numbers and sum to user
		�	End program
*/

#include <iostream>
#include <cstdlib> //For rand and srand
#include <ctime> //For time function

using namespace std;

int main()
{
	//Set constant variables for random number constraints
	const int MIN_VALUE = 1; //Min number for random number
	const int MAX_VALUE = 100; //Max number for random number
	
	//Set variables for random numbers and solution
	int num1, num2, numSum;
	
	//Set variables for pauses
	char ch;
	
	//Get system time
	unsigned seed = time(0);

	//Seed the random number generator
	srand(seed);
	
	//Display message to user to begin giving random integers
	cout << "Would you like to try and add some numbers?\nPress enter to begin" << endl;
	cin.get(ch);
	
	//Gets and displays the two random numbers to the user and pauses
	num1 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
	num2 = (rand() % (MAX_VALUE - MIN_VALUE + 1)) + MIN_VALUE;
	cout << "\n" << num1 << " + " << num2 << " = ?" << endl;
	cout << "Press enter to see solution" << endl;
	cin.get(ch);
	
	//Calculates sum of random numbers and displays sum to user.
	numSum = num1 + num2;
	cout << "\n" << num1 << " + " << num2 << " = " << numSum << endl;
	cout << "Press enter to exit" << endl;
	cin.get(ch);
	
	//End program
	return 0;
}