/*
	Amanda L. Costandine
	Chapters 1-3
	Production Exam 1 - Conversion
	
	
	Write a program which will as a take a person�s weight in pounds and convert it to kilograms.
	
	Algorithim:
		�	Set constant variables
		�	Set variables
		�	Prompt user to enter weight input
		�	Get weight input from user
		�	Calculate conversion from input
		�	Display input and results to user
		�	End program
*/

#include <iostream>
#include <iomanip> //For output formatting

using namespace std;

int main()
{
	//Set constant variables
	const double CONVERSION_FACTOR = 2.2046226218;

	//Set variables for input
	double weightLBS, weightKG;

	//Set variables for pauses
	char ch;

	//Prompt and receive weightLBS input from user
	cout << "Enter your weight in pounds (You may include up to two decimal places)" << endl;
	cin >> weightLBS;

	//Calculates conversion from weight in pounds to weight in kilograms
	weightKG = weightLBS * (1 / CONVERSION_FACTOR);

	//Displays input and result to user
	cout << "\nYour weight of " << setprecision(2) << fixed << weightLBS << " pounds would be " << setprecision(2) << fixed  << weightKG << " in kilograms." << endl;
	cout << "\nPress enter to exit" << endl;
	cin.get(ch);

	//End program
	return 0;
}