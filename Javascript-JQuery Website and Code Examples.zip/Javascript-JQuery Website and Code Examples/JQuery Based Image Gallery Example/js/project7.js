$('document').ready(function(){
//Pre-load images
preloadImages();
//Display first image
displayFirstImage();
//Load the gallery
gallery();
});
 
// function library
//Pre-load images function
function preloadImages(){
	//Creates array for all images
	var arrAllImages = [];
	//Gets image links
	var galleryImageLinks = $('#thumbs a');
	//Iterates for each image and creates object and gets source
	for (i=0; i<galleryImageLinks.length; i++) {
		//Creates new image object for each image to load image from server in array
		arrAllImages[i] = new Image();
		//Sets that new memeber source to whatever link the loop is on
		arrAllImages[i].src = galleryImageLinks[i];
	}; //End for loop
	//alert(arrAllImages[1].src); Check object sources
}; //End function pre-load images

//Display first image function
function displayFirstImage(){
	//Gets href attribute path of first image
	var firstPath = $('#thumbs a:first').attr('href');
	
	/**********For Project 7**********/
	//Gets alt attribute  of first image
	var firstAlt = $('#thumbs img:first').attr('alt');
	/**********For Project 7**********/
	
	//Makes html image script tag for big image
	var firstImage = '<img id="galleryBig" src="'+firstPath+'" alt="'+firstAlt+'">';
	//Sets first image after ul "thumbs" for display
	$('#thumbs').after(firstImage);
	
	/**********For Project 7**********/
	//Creates caption tag for first image
	var firstCaption = '<div id="caption">'+firstAlt+'</div>';
	//Sets caption tag after first image tag by id
	$('#galleryBig').after(firstCaption);
	/**********For Project 7**********/
	
}; //End function display first image

//Load the gallery function
function gallery(){
	//On thumbnail click
	$('#thumbs a').click(function(theClick){
		//Prevent default behavior of links
		theClick.preventDefault();
		//Gets last/old image
		var oldImage = $('#thumbs').next();	

		/**********For Project 7**********/
		//Gets old caption
		var oldCaption = $('#galleryBig').next();
		/**********For Project 7**********/
	
		//Gets  anchor href attribute of the clicked link
		var imgPath = $(this).attr('href');
		//Gets alt text from the image clicked
		var altText = $(this).children(':first').attr('alt');
		//Creates img html tag for gallery big image on click so big image changes
		var newImage = $('<img id="galleryBig" src="'+imgPath+'" alt="'+altText+'">');
		//Hides newImage html tag for placing and fade-in
		newImage.hide();
		//Places image on page after thumbnails by id, but does not display yet
		$('#thumbs').after(newImage);
		//Option for smoother fade in-fade out of gallery images
		/*oldImage.fadeOut(function(){
			oldImage.remove();
			newImage.fadeIn();
		});//End anon function callback*/
		//removes last/old image
		oldImage.remove();
		//Fades in newImage img tag for gallery big image
		newImage.fadeIn();
	
		/**********For Project 7**********/
		//Creates caption tag for new gallery big image that was clicked
		var newCaption = '<div id="caption">'+altText+'</div>';
		//Places caption tag after big image by id, but does not display yet
		$('#galleryBig').after(newCaption);
		//removes old caption
		oldCaption.remove();
		//Fades in new caption
		newCaption.fadeIn();
		/**********For Project 7**********/
	
	}); //End anon function theClick
}; //End function load the gallery