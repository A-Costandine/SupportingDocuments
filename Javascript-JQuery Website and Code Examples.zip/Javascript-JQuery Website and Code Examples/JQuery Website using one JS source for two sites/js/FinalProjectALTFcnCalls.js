$('document').ready(function(){
	//Function call to highlight current page
	currentPage('currentLink');
	
	//Function call to style tables
	styleTable('#fishfun', 'rowA', 'rowB', 'rowOver');
	
	//Function call to create photo gallery
	photoGallery('#gallery');
	
	//Function call for faq accordion
	accordion('#fishfaq');
	
	//Function call to style and validate form
	contactForm();
	
}); //End document ready