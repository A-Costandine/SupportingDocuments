$('document').ready(function(){
	//Function call to highlight current page
	currentPage('pageHighlight');
	
	//Function call to style tables
	styleTable('#duck_stories', 'row1', 'row2', 'rowTop');
	
	//Function call to control external links outside of tables
	linkControl('p a');
	
	//Function call to create photo gallery
	photoGallery('#gallery');
	
	//Function call for faq accordion
	accordion('#faqs');
	
	//Function call to style and validate form
	contactForm();
	
}); //End document ready
