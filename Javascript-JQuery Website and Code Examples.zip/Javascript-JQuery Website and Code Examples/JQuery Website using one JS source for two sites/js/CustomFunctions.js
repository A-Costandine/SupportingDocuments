//Shared Abstracted Functions for Both Sites

//Function to dynamically highlight current page in navbar
function currentPage(theClass){
	$('#navbar li a').each(function() {
		if ($(this).prop('href') == window.location.href) {
		$(this).addClass(theClass);
		}
	});
} //end function

//Function to style tables
function styleTable(theTable, rowOdd, rowEven, rowTop){
	$(theTable + ' tr:even').addClass(rowOdd);
	$(theTable + ' tr:odd').addClass(rowEven);
	$(theTable + ' tr:first').addClass(rowTop);
	$(theTable + ' tr td:even').css('text-decoration', 'underline');
	$(theTable + ' tr').hover().css({'cursor':'pointer'});
	if(rowTop == 'rowTop'){
		$('.' + rowTop).css('color', '#ffcc00');
	} //end if
	$(theTable + ' tr').click(function() {
        var url = $(this).find("a").attr("href");
		if(url) {
            window.open(url, '_blank');
        } //end if
    }); //end anon fcn
} //end function


//Note: This function was created outside of the tables function, so that it could be used only when needed, and any anchor could be passsed ot it as needed. As it stands, only the Final site uses this function, as the ALT site does not need it as it does not have external links outside of the tables. It is still abstracted. I just felt it was better left seperate to cut down on processing as much as possible and for better usability of the function.
//Function to control external links
function linkControl(whichAnchor){
	$(whichAnchor).click(function(theClick){
		theClick.preventDefault();
		var url = $(this).attr('href');
		if(url) {
            window.open(url, '_blank');
        } //end if
	}); //End anon function
} //end function

//Function to create the photo galleries
function photoGallery(theDiv){
	$(theDiv + ' a').click(function(evt){
		evt.preventDefault();
		
		//Image stuff
		var imgPath = $(this).attr('href');
		var oldImage = $('#photo img');
		var newImage = $('<div id="photo"><img src="' + imgPath + '"></div>');
		newImage.hide();
		$(theDiv).append(newImage);
		newImage.fadeIn(500);
		oldImage.remove();
		
		//Caption stuff
		var theTitle = $(this).attr('title');
		var oldCaption = $('#caption');
		var newCaption = $('<div id="caption"><center><b>'+ theTitle + '</b></center></div>');
		newCaption.hide();
		$('#photo img').after(newCaption);
		newCaption.fadeIn(500);
		oldCaption.remove();
		
	}); //end anon function on click
	$(theDiv + ' img:first').click();
} //End function


//Function to create all accordions
function accordion(acc){
	$(acc).accordion({
		active: false,
		collapsible: true,
		heightStyle: "content"
	}); //end anon function
} //end function

//Note: Custom method for jQuery Validator to not validate default values, must be outside main function and before validator call to work - this is not technically a function, but it is required for the validation to work.
$.validator.addMethod(
    'noPlaceholder', function (value, element) {
        return value !== element.defaultValue;
    }, 'Please enter a non-default value.'
); //End custom method

//Function to style and validate forms
function contactForm(){
	
	//Insert jQuery UI datepicker into date field and disable future dates
	$("#date").datepicker({ maxDate: new Date });
	
	//Autoclear and replace default inputs
	var textElements = $('input[type=text], textarea');
	
	//When these items focus, fire...
	textElements.focus(function(){
		//Variable to get the default value of the clicked (focused) element
		var defVal = $(this).prop('defaultValue');
		//Variable to get the current value of the clicked (focused) element
		var curVal = $(this).val();
		//Compare the two values (default and current)
		if (defVal == curVal) {
			//If the are the same, reset current value to empty string
			$(this).val('');
		} //End if
	}); //End anon function
	
	//When user leaves field, see if it is blank, if so, put back the default value
	textElements.blur(function(){
		//If the value is empty, replace default value
		if($(this).val() == '') {
			$(this).val($(this).prop('defaultValue'));
			//Alternate code
			//$(this).val($(this).attr('value'));
		} //End if
	}); //End anon function
	//End autoclear and replace default inputs
	
	//Validate form
	//Add form id and name attributes
	$('form').attr('id', 'contactForm');
	$('form').attr('name', 'contactForm');
	
	//The call to the validator plugin function
	var isvalidate = $("#contactForm").validate({
		//Create rules
		rules : {
			name1 : {
				required : true,
				rangelength:[2,25],
				noPlaceholder: true
			},
			name2 : {
				required : true,
				rangelength:[2,25],
				noPlaceholder: true
			},
			email : {
				required : true,
				email : true
			},
			date : {
				required : true,
				date : true
			}
		}, //End rules
		//Create error messages
		messages : {
			name1 : {
				required : "You must enter your name.",
				rangelength : "Your name must be at least 2 characters long and no more than 25 characters long."
				
			},
			name2 : {
				required : "You must enter your  last name.",
				rangelength : "Your name must be at least 2 characters long and no more than 25 characters long."
			},
			email : {
				required : "You must enter your email.",
				email : "You must enter a valid email."
			},
			date : {
				required : "You must enter a sighting date.",
				date : "You must enter a valid sighting date."
			}
		} //End error messages
	}); //End validate
} //End function
