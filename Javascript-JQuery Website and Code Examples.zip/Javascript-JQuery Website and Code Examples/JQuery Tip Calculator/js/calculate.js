$('document').ready(function(){
	//Calculate function
	$('#tipCalc').submit(calculate);
	//Function call to hide bob email
	hideEmail('.bobEmail', 'bob', 'example.com');
	//Function call to hide bobbie email
	hideEmail('.bobbieEmail', 'bobbie', 'example.com');
	//Function to automatically focus on first form input box (pass id)
	autoFocus('#name');
	//Function to auto-clear default inputs on the form
	autoClear();
	//Function to toggle dependent radio buttons from parent checkbox
	toggleDepends('#round', 'input[type=radio][name=roundTo]');
	//Function to validate form
	validateForm();
});

//Functions

//Begin calculate functions (alter at own risk)
function calculate(evt){
evt.preventDefault();
var allHashes = [];
var inputs = $('#tipCalc').find('input:not(:submit)');
for(var i=0; i<inputs.length; i++){
	if($(inputs[i]).is(':input[type=text]') && $(inputs[i]).val() != ''){
		allHashes[$(inputs[i]).attr('id')] = $(inputs[i]).val();
	}
	if($(inputs[i]).prop('checked')){
		allHashes[$(inputs[i]).attr('name')] = $(inputs[i]).val();
	}
}

$('#totalBill').text('Total bill: $' + allHashes['total']);
var tip = allHashes['total'] * allHashes['percent'] / 100;

if($('#round').prop('checked')){
	if(allHashes['roundTo']=='int'){
		//round to dollar (I changed this to round up to the next dollar)
		tip = Math.ceil(tip);
	} else if(allHashes['roundTo']=='ten'){
		//round to dime
		tip = Math.round(tip*10)/10;
		tip = parseFloat(tip).toFixed(2);
	} else if(allHashes['roundTo']=='hun'){
		// round to cent
		tip = Math.round(tip * 100)/100;
		tip = parseFloat(tip).toFixed(2);
	}
}

$('#totalTip').text('Total tip: ' + allHashes['percent'] + '% is $' + tip);
var msg = '<h4 id="message">That\'s a very ' + allHashes['gender'] + ' tip, ' + allHashes['name'] + '!</h4>';
$('#totalTip').next().remove();
$('#totalTip').after(msg);
}
//End calculate functions

//Functions I added
//Funtion to hide email
function hideEmail(emailClass, user, domain) {
	//Variable for buliding email address
	var address = user + '@' + domain;
	//Variable to create the email link for html
	var emailLink = '<a href="mailto:'+address+'">'+address+'</a>';
	//Select emailClass span tag and replace the email with emailLink variable
	$(emailClass).html(emailLink);
} //End function

//Function to automatically focus on first form input box
function autoFocus(focusMe) {
	//Focuses the input box with passed id
	$(focusMe).focus();
} //End function

//Function to auto-clear default inputs on the form
function autoClear(){
/* Algorithim
	1 - Find all elements that might have default text
	2 - Compare the current value to the default value, if they are the same, clear it
	3 - On blur(leaving field), if left empty, put back the default value
*/
	//Find all elements that might have default text (Select all input fields where the type is text, email and password, and all textarea fields)
	var textElements = $('input[type=text], input[type=email], input[type=password], textarea');
	
	//When these items focus, fire...
	textElements.focus(function(){
		//Variable to get the default value of the clicked (focused) element
		var defVal = $(this).prop('defaultValue');
		//Variable to get the current value of the clicked (focused) element
		var curVal = $(this).val();
		//Compare the two values (default and current)
		if (defVal == curVal) {
			//If the are the same, reset current value to empty string
			$(this).val('');
		} //End if
	}); //End anon function
	
	//When user leaves field, see if it is blank, if so, put back the default value
	textElements.blur(function(){
		//If the value is empty, replace default value
		if($(this).val() == '') {
			$(this).val($(this).prop('defaultValue'));
			//Alternate code
			//$(this).val($(this).attr('value'));
		} //End if
	}); //End anon function
} //End function

//Function to toggle dependent radio buttons from parent checkbox
function toggleDepends(dependControl, radios){
/* Algorithim
	1 - Set dependents to initially disable
	2 - When parent is selected:
		a - Check for the parent's state
		b - If selected, enable the dependents. if not selected, disable the dependents
*/

//1
	//Find radio buttons that are dependent on the parent checkbox input then set to disabled for inital page load
	$('form').find(radios).each(function(){
		$(this).attr('disabled', true);
	}); //End anon function
	//Find the previous sibling tags to the radio button inputs(labels) and grey them out along with the radio buttons
	$('form').find(radios).prev().each(function(){
		$(this).css('color', '#999');
	}); //End anon function
	
//2
	//a - Check the parent's state
	//Check the parent checkbox to see if it has been checked(by id)
	$(dependControl).click(function(){
		//If the parent checkbox is checked(true)
		if ($(this).is(':checked') == true) {
			//Enable radio buttons
			$('form').find(radios).each(function(){
				$(this).attr('disabled', false);
			}); //End anon function
			//Set label text back to black
			$('form').find(radios).prev().each(function(){
				$(this).css('color', '#000');
			}); //End anon function
		}
		//b - If is not checked or unchecked
		else {
			//Set radio buttons back to disable
			$('form').find(radios).each(function(){
				$(this).attr('disabled', true);
			}); //End anon function
			//Set text back to grey
			$('form').find(radios).prev().each(function(){
				$(this).css('color', '#999');
			}); //End anon function
		} //End if
	}); //End anon function
} //End function

//Function to validate form
function validateForm(){
	var validator = $('#tipCalc').validate({
		rules : {
			//Require Name
			name : {
				required : true,
				rangelength:[2,25]
			}, //End require name
			//Require gender
			gender : {
				required : true
			}, //End require gender
			//Require total bill and require the entry be numbers
			total : {
				required : true,
				number : true
			}, //End total
			//Require tip percent and require the entry be numbers
			percent : {
				required: true,
				number : true
			} //End percent
		}, //End rules
		//Create error messages
		messages : {
			//Error message for name
			name : {
				required : "You must enter your name.",
				rangelength : "Your name must be at least 2 characters long and no more than 25 characters long."
			}, //End name error message
			//Error message for gender
			gender : {
				required : "You must choose a gender."
			}, //End gender error message
			//Error messages for total bill
			total : {
				required : "You must enter your total bill.",
				number : "You must enter a valid number (no symbols)."
			}, //End total error messages
			//Error messages for tip percent
			percent : {
				required : "You must enter a tip percentage.",
				number: "You must enter a valid number (no symbols)."
			}, //End percent error messages
		}, //End error messages
		//To move radio button error message to different position
		errorPlacement: function(error, element){
			if ( element.is(":radio")) {
				error.appendTo( element.parent());
			}
			else {
				error.insertAfter(element);
			} //End if-else
		}, //End error placement
		submitHandler: function(e) {
                $('#totalBill').show();
                $('#totalTip').show();
                $('#message').show();
                $('.error').remove();
        }, //End submit handler
		invalidHandler: function(i){
                $('#totalBill').hide();
                $('#totalTip').hide();
				$('#message').hide();
        } //End invalid handler*/
	}); //End validate
} //End function