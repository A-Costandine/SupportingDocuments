$('document').ready(function(){
	initializePage(); //Set initial state of page
	setInterval('rotateImages()', 4000);
});
 
 //Functions
 //Function to initialize page
 function initializePage() {
	 $('#photoShow').css({'height':'445px', 'width':'445px'});
	 $('#photoShow img').css({opacity:0.0});
	 $('#photoShow img:first').css({opacity:1.0});
 }
 
 //Function to run slideshow
function rotateImages(){
	$('#photoShow img').css({opacity:0.0});
	var currentPhoto = $('#photoShow img.current');
	var nextPhoto = currentPhoto.next();
	if(nextPhoto.length == 0){
		nextPhoto = $('#photoShow img:first');
	} // end if
	currentPhoto.removeClass('current').addClass('previous');
	nextPhoto.css({opacity:0.0}).addClass('current').animate({opacity:1.0}, 2000, function(){
		currentPhoto.removeClass('previous');
	}); // end callback
	//Get height, width of next photo, then change div to match on interval
	var photoShowW = $('#photoShow img.current').width();
	var photoShowH = $('#photoShow img.current').height();
	$('#photoShow').animate({width:photoShowW+'px', height:photoShowH+'px'}, 250, 'swing');
} // end rotateImages
