$('document').ready(function(){
	//Function call for tabbed panels
	tabbedPanels('#panels');
	//Function call for Major scale accordion
	accordion('#majorScaleAcc');
	//Function call for Melodic minor scale accordion
	accordion('#minorScaleAcc');
}) // End document ready

//Functions
//Function to create tabbed panels
function tabbedPanels(panels) {
	$(panels).tabs({
		active: 0
	}); //End anon function
} //End funtion

//Function to create all accordions
function accordion(acc){
	$(acc).accordion({
		active: false,
		collapsible: true,
		heightStyle: "content"
	}); //end anon function
} //end function