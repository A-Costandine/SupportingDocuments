<!--Author:   Amanda L. Costandine
	Date:     04/08/2016
	File:	  dairyFunctions.php
	Purpose:  Functions Assignment
-->
<?php
//--------------Functions--------------//

//Welcome function
function welcome() {
	$welcome = 'Welcome to Dairy Town';
	return $welcome;
}

//Names function
function fullName($firstName, $lastName) {
	$firstName = "John";
	$lastName = "Doe";
	$fullName = "".$firstName." ".$lastName."";
	return $fullName;
}

//Toppings function
function displayToppings($extras) {	
		echo '<ul>';
			foreach($extras as $topping) {
				echo '<li>'.$topping.'</li>';
			}
		echo '</ul>';
}

//Return Some Change function
function ringItUp($totalCost, $paymentFromCustomer) {
	$change = ($paymentFromCustomer - $totalCost);
	return $change;
}

?>