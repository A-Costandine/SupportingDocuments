<!--Author:   Amanda L. Costandine
	Date:     04/08/2016
	File:	  index.php
	Purpose:  Functions Assignment
-->
<?php
/*
//--------------Functions--------------//

//Welcome function
function welcome() {
	$welcome = 'Welcome to Dairy Town';
	return $welcome;
}

//Names function
function fullName($firstName, $lastName) {
	$firstName = "John";
	$lastName = "Doe";
	$fullName = "".$firstName." ".$lastName."";
	return $fullName;
}

//Toppings function
function displayToppings($extras) {	
		echo '<ul>';
			foreach($extras as $topping) {
				echo '<li>'.$topping.'</li>';
			}
		echo '</ul>';
}

//Return Some Change function
function ringItUp($totalCost, $paymentFromCustomer) {
	$change = ($paymentFromCustomer - $totalCost);
	return $change;
}
*/


//-------------Main Program-------------//

include_once('dairyFunctions.php');

//Welcome program
echo '<h1>'.welcome().'</h1>';

//Names program
echo 'Thank you for your order, '.fullName($firstName, $lastName).'.';

//Toppings program
echo ' You have selected the following toppings:';
$extras = array('Chocolate Sauce', 'Whipped Cream', 'Sprinkles');
echo ''.displayToppings($extras).'';

//Return Some Change program
$totalCost = 10.00;
$paymentFromCustomer = 15.00;
$change = ringItUp($totalCost, $paymentFromCustomer);

echo 'Your order cost $'.$totalCost.'<br>';
echo 'Your payment was $'.$paymentFromCustomer.'<br>';
echo 'Your change is $'.$change.'<br>';

echo '
	<br><br>    
	<hr>
	<center><a href="../../../php.html">Back to PHP</a></center>
	<center><a href="../../../index.html">Home</a></center>
	';

?>