<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>String Comparison</title>
</head>
<body>

<h1>Compare Strings</h1>

<?php

if (isset($_GET['btn_submit'])) {
    // Input
    $string1 = $_GET['string1'];
    $string2 = $_GET['string2'];

    // Processing
	if ($string1 == '' OR $string2 == '') {
		echo 'Error: Must enter valid strings in all imput areas';
	}
	else {
		$result = strcmp($string1, $string2);
	
		if ($result <0 ) {
			echo '<b>String 1:</b> '.$string1.'<br>
				  <b>String 2:</b> '.$string2.'<br><br>';
			echo ''.$string1.' comes before '.$string2.'';
		}
		elseif ($result == 0) {
			echo '<b>String 1:</b> '.$string1.'<br>
				  <b>String 2:</b> '.$string2.'<br><br>';
			echo ''.$string1.' is equal to '.$string2.'';
		}
		else {
			echo '<b>String 1:</b> '.$string1.'<br>
				  <b>String 2:</b> '.$string2.'<br><br>';
			echo ''.$string1.' comes after '.$string2.'';
		}
	}

    //Extra Output
	//Displays the current "$message" value
	echo $message;
	echo '<br /><br />';
	//Adds a return button to go back to the original form
	echo '<form name="return" action="compare_strings.php">
				<input type="submit" value="Compare Another String" name="btn_return" />
		  </form>';
	//navagation to the html file
	echo '<br><br>
		  <hr>
		  <center><a href="index.html">Back to Strings and Numbers</a></center>
		  <center><a href="../../../starts.html">Back to Starts/Chapters</a></center>
		  <center><a href="../../../index.html">Home</a></center>';

} else {
?>

<form name="compare" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<table>
		<tr>
			<td>
				<p>Enter the first string: &nbsp;</p>
			</td>
			<td>
				<input type="text" name="string1" method="post" />
			</td>
		</tr>
		<tr>
			<td>
				<p>Enter the second string: &nbsp;</p>
			</td>
			<td>
			    <input type="text" name="string2" method="post" />
			</td>
		<tr colspan="2">
			<td>
				<input type="submit" value="Submit" name="btn_submit" />
			</td>
	</table>
</form>
</body>
	<br><br>    
	<hr>
	<center><a href="../../../php.html">Back to PHP</a></center>
	<center><a href="../../../index.html">Home</a></center>
</html>

<?php }  // end of else ?>
