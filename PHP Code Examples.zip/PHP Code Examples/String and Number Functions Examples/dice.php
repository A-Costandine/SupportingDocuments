<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Dice Roll</title>
</head>
<body>

<h1>Virtual Die</h1>

<?php

if (isset($_GET['btn_submit'])) {
    // Processing
	
	//Generates a random number between 1 and 6 and assigns it to a variable
	$dice = mt_rand(1, 6);
	
	//Displays corresponding die image to variable generated
	echo '<img src="dice/die_0'.$dice.'.gif">';
	
	//Checks the value of the variable and displays the corresponding image file
	/*switch($dice) {
		case 1:
			echo '<img src="dice/die_01.gif">';
			break;
		case 2:
			echo '<img src="dice/die_02.gif">';
			break;
		case 3:
			echo '<img src="dice/die_03.gif">';
			break;
		case 4:
			echo '<img src="dice/die_04.gif">';
			break;
		case 5:
			echo '<img src="dice/die_05.gif">';
			break;
		case 6:
			echo '<img src="dice/die_06.gif">';
			break;
	}*/

    // Output
	//Adds a return button to go back to the original form
	echo '<form name="return" action="dice.php">
				<input type="submit" value="Roll Again" name="btn_submit" />
		  </form>';
	//navagation to the html file
	echo '<br><br>
		  <hr>
		  <center><a href="index.html">Back to Strings and Numbers</a></center>
		  <center><a href="../../../starts.html">Back to Starts/Chapters</a></center>
		  <center><a href="../../../index.html">Home</a></center>';

} else {
?>

<img src="dice/die_01.gif">

<form name="email" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <p><input type="submit" value="Roll the Die" name="btn_submit" />
    </p>
</form>
</body>
	<br><br>    
	<hr>
	<center><a href="../../../php.html">Back to PHP</a></center>
	<center><a href="../../../index.html">Home</a></center>
</html>

<?php }  // end of else ?>
