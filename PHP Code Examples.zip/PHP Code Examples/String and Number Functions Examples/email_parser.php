<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Email Parser</title>
</head>
<body>

<h1>Email Parser</h1>

<?php

if (isset($_GET['btn_email'])) {
    // Input
    $email_address = $_GET['email_address'];

    // Processing

    // this assumes that the user does not have a name with a period in it
    // such as charlie.wallin
		
	//Sets default display message
	$message = 'Your E-mail Address Parsed';
	
	//Checks to see if the string is empty, if is it, throws an error
	if (empty($email_address)) {
		$message = 'Error: Must enter valid E-mail address';
	}
	//If the string isn't empty, processes the string
	else {
		//Finds the "@" string position
		$a = strpos($email_address, '@');
		//Checks to see if "@" position is false, if so throws an error message
		if ($a === false) {
			$message = 'Error: Email address must include one "@" symbol';
		}
		//If a "@" position is found, processes string segment "$user"
		else {
			$user = substr($email_address, 0, $a);
		}
		//Finds the "." string postition
		$b = strpos($email_address, '.');
		//Counts how many instances of "." were found in the string
		$dot = substr_count($email_address, '.');
		//Checks to see if "." position is false, if so throws an error message
		if ($b === false) {
			$message = 'Error: Email must include one "." symbol';
		}
		//Checks to see if more than one "." occurs in the string, if so throws an error message
		elseif ($dot > 1) {
			$message = 'Error: Email must include ONLY one "." symbol';
		}
		//If a "." postion is found, and there is only one, processes the string segment "$tld"
		else {
			$tld = substr($email_address, $b);
		}
		//Assigns the postion end value for the middle string segment
		$c = $b - $a;
		//Checks to see if "$c" is false, if so throws an error message
		if ($c === false) {
			$message = 'Error: Must enter valid E-mail address';
		}
		//If a "$c" is not false, processes the string segment "$domain"
		else {
			$domain = substr($email_address, $a+1, $c-1);
		}
		//Checks to see that all three variables are not empty, if they are not empty echos the variables.
		if ($user != '' AND $domain != '' AND $tld != '') {
			echo 'User: '.$user.'<br />
				  Domain: '.$domain.'<br />
				  TLD: '.$tld.'';
			echo '<br /><br />';
		}
	}


    //Extra Output
	//Displays the current "$message" value
	echo $message;
	echo '<br /><br />';
	//Adds a return button to go back to the original form
	echo '<form name="return" action="email_parser.php">
				<input type="submit" value="Parse Another Email" name="btn_return" />
		  </form>';
	//navagation to the html file
	echo '<br><br>
		  <hr>
		  <center><a href="index.html">Back to Strings and Numbers</a></center>
		  <center><a href="../../../starts.html">Back to Starts/Chapters</a></center>
		  <center><a href="../../../index.html">Home</a></center>';
} 
else { 

?>

<form name="email" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <p>Enter your email address: &nbsp;<input type="text" name="email_address" method="post" /><br><br>
    <input type="submit" value="Submit" name="btn_email" />
    </p>
</form>
</body>
	<br><br>    
	<hr>
	<center><a href="../../../php.html">Back to PHP</a></center>
	<center><a href="../../../index.html">Home</a></center>
</html>

<?php }  // end of else ?>
