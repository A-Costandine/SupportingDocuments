<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Cards Array</title>
</head>
<body>

<h1>Cards Array</h1>

<?php
// cards
$deck = array 
(
's01.png',
's02.png',
's03.png',
's04.png',
's05.png',
's06.png',
's07.png',
's08.png',
's09.png',
's10.png',
's11.png',
's12.png',
's13.png',
'd01.png',
'd02.png',
'd03.png',
'd04.png',
'd05.png',
'd06.png',
'd07.png',
'd08.png',
'd09.png',
'd10.png',
'd11.png',
'd12.png',
'd13.png',
'h01.png',
'h02.png',
'h03.png',
'h04.png',
'h05.png',
'h06.png',
'h07.png',
'h08.png',
'h09.png',
'h10.png',
'h11.png',
'h12.png',
'h13.png',
'c01.png',
'c02.png',
'c03.png',
'c04.png',
'c05.png',
'c06.png',
'c07.png',
'c08.png',
'c09.png',
'c10.png',
'c11.png',
'c12.png',
'c13.png'
);

echo '<hr>';

echo '<h2>Display Deck</h2>';

//Displays deck with a for loop
$deck_display = '';
for ($i = 0; $i < count($deck); $i++) {
	$deck_display = $deck[$i];

echo '<img src="cards/'.$deck_display.'">';
}

echo '<hr>';

echo '<h2>Sort Cards by Key</h2>';

//Sorts cards by key
ksort($deck);
//Displays sorted array
foreach ($deck as $key => $val) {
    echo '<img src="cards/'.$val.'">';
}

echo '<hr>';

echo '<h2>Display Suit of Spades</h2>';

//Displays suit of spades array with for loop
foreach ($deck as $spade) {
	
	//Gets the first letter/entitiy of each string
	$spadeChar = substr($spade, 0, 1);
	
	//Tests to see if that entitiy is "s", if so displays corresponding card image
	if ($spadeChar == "s") {
		echo '<img src="cards/'.$spade.'">';
	}
	
}

echo '<hr>';

echo '<h2>Shuffle Deck</h2>';

//Creates a copy of the original array
$deck_shuffle = $deck;

//Shuffles the $deck_shuffle array
shuffle($deck_shuffle);

//Displays the shuffled deck array with for loop
for ($i = 0; $i < count($deck_shuffle); $i++) {
	$deck_shuffle_display = $deck_shuffle[$i];

echo '<img src="cards/'.$deck_shuffle_display.'">';
}

echo '<br>Refresh page to get fresh shuffle';

echo '<hr>';

echo '<h2>Deal Five Cards</h2>';

//Gets 5 random key values from $deck array and creates new array
$deck_rand = array_rand($deck, 5);

//uses $deck_rand array to get all key values with for loop into new array $deck_deal, then displays using $deck_deal as keys for the original array (arrayception)
for ($i = 0; $i < count($deck_rand); $i++) {
	$deck_deal = $deck_rand[$i];

echo '<img src="cards/'.$deck[$deck_deal].'">';
}

echo '<br>Refresh page to get fresh hand';

echo '<hr>';

echo '<h2>Odd Numbered Cards</h2>';

//Checks each value with a foreach loop
foreach ($deck as $card) {
	
	//Gets card number from the loop by ignoring the first character and looking for the folllowing two characters
	$cardNum = substr($card, 1, 2);
	
	//Tests the cardNum to see if it starts with a zero, if so, removes the zero for mathmatical purposes
	if(substr($cardNum, 0, 1) == 0) {
		$cardNum = substr($cardNum, 1, 1);
	}
	//Tests the cardNum to see if it is odd numbered by division and remainder, then displays the corrsponding image file
	if (($cardNum % 2) == 1) {
		echo '<img src="cards/'.$card.'">';
	}
	
}

echo '<hr>';

//My created problem
echo '<h2>Jokers Are Wild</h2>';

echo 'Add the two joker cards to the end of the deck array, then display the two joker cards in a poker hand with three other random cards to see if you can beat the other players<br><br>';

//Creates copy of original array
$deck_joker = $deck;

//Add jokers to copy of array
$deck_joker[] = 'xj01.png';
$deck_joker[] = 'xj02.png';

//Displays the jokers with for loop
foreach ($deck_joker as $joker) {
	
	//Gets the first letter/entitiy of each string
	$jokerChar = substr($joker, 0, 2);
	
	//Tests to see if that entitiy is "xj", if so displays corresponding joker card image
	if ($jokerChar == "xj") {
		echo '<img src="cards/'.$joker.'">';
	}
}

//Gets 5 random key values from $deck (one without jokers) array and creates new array
$deck_rand = array_rand($deck, 3);

//uses $deck_rand array to get all key values with for loop into new array $deck_deal, then displays using $deck_deal as keys for the original array (arrayception)
for ($i = 0; $i < count($deck_rand); $i++) {
	$deck_deal = $deck_rand[$i];

echo '<img src="cards/'.$deck[$deck_deal].'">';
}

echo '<br>Refresh page to get fresh hand';

echo '<hr>';

echo '<h2>Count Array</h2>';

echo 'Figure out the number of elements in the deck array, then display the count<br><br>';

//counts the number of elements in the array (not one with jokers)
$deck_count = count($deck);

echo ''.$deck_count.'';

echo '<hr>';

?>

</body>
	<br><br>    
	<hr>
	<center><a href="../../../php.html">Back to PHP</a></center>
	<center><a href="../../../index.html">Home</a></center>
</html>