<?php
// Get the product data
$category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
$product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
$product_code = filter_input(INPUT_POST, 'product_code');
$product_name = filter_input(INPUT_POST, 'product_name');
$list_price = filter_input(INPUT_POST, 'list_price', FILTER_VALIDATE_FLOAT);

// Validate inputs
if ($category_id == null || $category_id == false || $product_id == null || $product_id == false || $product_code == null || $product_name == null || $list_price == null || $list_price == false) {
    $error = "Invalid product data. Check all fields and try again.";
    include('error.php');
} else {
    require_once('database.php');

    // Update the product to the database  
    $query = 'UPDATE products
			  SET categoryID = :category_id, productCode = :product_code, productName = :product_name, listPrice = :list_price
			  WHERE productID = :product_id';
    $statement = $db->prepare($query);
    $statement->bindValue(':category_id', $category_id);
    $statement->bindValue(':product_id', $product_id);
    $statement->bindValue(':product_code', $product_code);
    $statement->bindValue(':product_name', $product_name);
    $statement->bindValue(':list_price', $list_price);
    $statement->execute();
    $statement->closeCursor();

    // Display the Product List page
    include('index.php');
}
?>