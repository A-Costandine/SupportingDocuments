<?php
//set default values
$name = '';
$email = '';
$phone = '';
$message = 'Enter some data and click on the Submit button.';

//process
$action = filter_input(INPUT_POST, 'action');

switch ($action) {
    case 'process_data':
	    /*************************************************
         * validate and process the name
         ************************************************/
        // 1. make sure the user enters a name
        // 2. display the name with only the first letter capitalized
        $name = trim(filter_input(INPUT_POST, 'name'));
		$name = ucwords(strtolower($name));
		if (empty($name)) {
			$message = 'Error: Must enter full name';
			break;
		}
		$i = strpos($name, ' ');
		if ($i === false) {
			$message = 'Error: Please enter full name';
			break;
		}
		else {
			$firstName = substr($name, 0, $i);
			$lastName = substr($name, $i + 1);
		}
		
        /*************************************************
         * validate and process the email address
         ************************************************/
        // 1. make sure the user enters an email
        // 2. make sure the email address has at least one @ sign and one dot character
        $email = trim(filter_input(INPUT_POST, 'email'));
		if (empty($email)) {
			$message = 'Error: Must enter email address';
			break;
		}
		elseif (strpos($email, '@') === false) {
			$message = 'Error: Email address must include an "@" symbol';
			break;
		}
		elseif (strpos($email, '.') === false) {
			$message = 'Error: Email must include at least one "." symbol';
			break;
		}
		
        /*************************************************
         * validate and process the phone number
         ************************************************/
        // 1. make sure the user enters at least seven digits, not including formatting characters
        // 2. format the phone number like this 123-4567 or this 123-456-7890
        $phone = trim(filter_input(INPUT_POST, 'phone'));
		$phone = str_replace('-', '', $phone);
		$phone = str_replace('(', '', $phone);
		$phone = str_replace(')', '', $phone);
		$phone = str_replace(' ', '', $phone);
		if (strlen($phone) != 7 AND strlen($phone) != 10) {
			$message = 'Error: Must enter a valid phone number';
			break;
		}
		if (strlen($phone) == 7) {
			$numSegOne = substr($phone, 0, 3);
			$numSegTwo = substr($phone, 3);
			$phone = $numSegOne. '-' .$numSegTwo;
		}
		elseif (strlen($phone) == 10) {
			$numSegOne = substr($phone, 0, 3);
			$numSegTwo = substr($phone, 3, 3);
			$numSegThree = substr($phone, 6);
			$phone = $numSegOne. '-' .$numSegTwo. '-' .$numSegThree;
		}
		
        /*************************************************
         * Display the validation message
         ************************************************/
        $message = "Hello $firstName,\n\n" .
                   "Thank you for entering this data:\n\n" .
				   "Name: $name\n" .
				   "Email: $email\n" .
				   "Phone: $phone";

        break;
}
include 'string_tester.php';
?>