<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <title>Palindrome</title>
</head>
<body>

<h1>Palindrome Checker</h1>

<?php
// notice that the post is checking to see if the
// submit button has been clicked.
if(isset($_GET['btn_submit'])) {
	//Gets value from form, makes string lowercase and trims whitespace from each end
    $palindrome_ori = $_GET['palindrome_ori'];
	$palindrome = trim(strtolower($palindrome_ori));
	
	//Checks how many instances of spaces there are
	$count_space = substr_count($palindrome, ' ');
	//If spaces exist in string, replaces spaces with no space
	if ($count_space > 0) {
		$palindrome = str_replace(' ', '', $palindrome);
	}
	
	//Checks how many instances of "." occur in the string
	$count_dot = substr_count($palindrome, '.');
	//If "." exist in string, replaces "." with no space
	if ($count_dot > 0) {
		$palindrome = str_replace('.', '', $palindrome);
	}
	
	//Checks how many instances of "'" occur in the string
	$count_dot = substr_count($palindrome, "'");
	//If "'" exist in string, replaces "'" with no space
	if ($count_dot > 0) {
		$palindrome = str_replace("'", "", $palindrome);
	}
	
	//Creates a varaiable with the edited string reversed
	$palindrome_rev = strrev($palindrome);
	
	//Compares $palindrome and $palindrome_rev
	$result = strcmp($palindrome, $palindrome_rev);
	//Checks to see if first string comes before second string, notifies user that string is not a palindrome
	if ($result < 0 ) {
		echo 'Sorry, "'.$palindrome_ori.'" is not a true palindrome, please try again';
	}
	//Checks to see if first string is equal to the second string, notifies user that string is a palindrome
	elseif ($result == 0) {
		echo 'Congratulations! "'.$palindrome_ori.'" is a true palindrome';
	}
	//Checks to see if first string comes after second string, notifies user that string is not a palindrome
	else {
		echo 'Sorry, "'.$palindrome_ori.'" is not a true palindrome, please try again';
	}

    //Extra Output
	echo '<br /><br />';
	//Adds a return button to go back to the original form
	echo '<form name="return" action="palindrome.php">
				<input type="submit" value="Check Another Palindrome" name="btn_return" />
		  </form>';
	//navagation to the html file
	echo '<br><br>
		  <hr>
		  <center><a href="../../../starts.html">Back to Starts/Chapters</a></center>
		  <center><a href="../../../index.html">Home</a></center>';
	
} else {    
?>
<!-- display the html form for user input -->
<form name="pal" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <p>Enter your palindrome: &nbsp;<input type="text" name="palindrome_ori" method="post" /><br><br>
    <input type="submit" value="Submit" name="btn_submit" />
    </p>
</form>
</body>
	<br><br>    
	<hr>
	<center><a href="../../../php.html">Back to PHP</a></center>
	<center><a href="../../../index.html">Home</a></center>
</html>

<?php }  // end of else ?>
