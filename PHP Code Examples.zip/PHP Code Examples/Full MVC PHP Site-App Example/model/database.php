<?php
	/*$dsn = 'mysql:host=localhost;dbname=my_guitar_shop1';
    $username = 'root';
    $password = '';*/
	
    if($_SERVER['HTTP_HOST'] == 'acostandine.x10host.com') {
        $dsn = 'mysql:host=localhost;dbname=acostand_WEB182';
        $username = 'acostand_user';
        $password = 'pa55word';
    }
    else {
        $dsn = 'mysql:host=webtech.db;dbname=my_guitar_shop1';
        $username = 'seekaydub';
        $password = 'x';
    }
	
    try {
        $db = new PDO($dsn, $username, $password);
    } catch (PDOException $e) {
        $error_message = $e->getMessage();
        include('../errors/database_error.php');
        exit();
    }
?>