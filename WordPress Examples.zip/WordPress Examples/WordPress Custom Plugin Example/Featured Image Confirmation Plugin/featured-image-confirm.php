<?php
/*
Plugin Name: Add Featured Image Metabox + Confirm Featured Image
Plugin URI: 
Description: Adds featured image metabox to themes that do not have it already added, and provides a prompt if user is about to publish a post without a featured image to make sure it was intentional.
Version: 1.0
Author: Amanda L. Costandine
Author URI:
License: GPL2
*/


//Function to add featured image metabox
add_theme_support( 'post-thumbnails' ); 

//Function to confirm featured image
$message = 'You didn\'t add a featured image, are you sure you want to publish this post without adding one?';
function confirm_image_post() {
	if ( !get_the_post_thumbnail() ) {
		global $message;
		echo '
		<script type="text/javascript"><!--
		var publishButton = document.getElementById("publish");
		if (publishButton !== null) publishButton.onclick = function(){
			return confirm("'.$message.'");
		};
		// --></script>';
	}
}

add_action('admin_footer', 'confirm_image_post');
?>