 <!--Begin Footer Area-->
        <footer>
            <!--Footer Content Container-->
            <div id="footerContent">
                <!--Footer Top Bar and Text-->
                <div id="footerContentTop">
                    <div id="footerContentTopText">
                        Naturetour has 25 years experience in operating wildlife holidays. Contact Us for friendly travel advice 
                    </div>
                </div>
                <!--Footer Main Content Area-->
                <div id="footerContentBottom">
                    <!--Footer Content Left Column-->
                    <div id="footerContentBottomLeft">
                        <!--Footer Content Left Column Heading-->
                        <div id="footerTwitterHeading">
                            <h3>
                                Follow Us on Twitter
                            </h3>
                        </div>
                        <!--Footer Content Left Column Content-->
                        <div id="footerTwitterText">
                            <p><span class="footerTwitterSmallText">* 4 days ago</span> The new website is now live. We hope you enjoy it and any feedback is welcome.
                            </p>
                        </div>
                        <div id="footerFacebookButton">
                            <a href="http://www.facebook.com"></a>
                        </div>
                        <div id="footerContentBottomLeftLine">
                        </div>
                    </div>
                    <!--Footer Content Middle Column-->
                    <div id="footerContentBottomMid">
                        <!--Footer Content Middle Column Heading-->
                        <h3>
                            Quick Links
                        </h3>
                        <!--Footer Content Middle Column Content-->
                        <!--Right Footer Middle Column Content Links-->
                        <ul>
                            <li>
                                <a href="#">Holidays by destination</a>
                            </li>
                            <li>
                                <a href="species.html">Holidays by species</a>
                            </li>
                            <li>
                                <a href="#">Holidays by tour type</a>
                            </li>
                            <li>
                                <a href="#">Late availability</a>
                            </li>
                            <li>
                                <a href="#">Tour leaders</a>
                            </li>
                        </ul>
                        <!--Middle Footer Middle Column Content Links-->
                        <ul>
                            <li>
                                <a href="#">How to book</a>
                            </li>
                            <li>
                                <a href="#">FAQs</a>
                            </li>
                            <li>
                                <a href="#">Visit Us</a>
                            </li>
                            <li>
                                <a href="#">Terms &amp; conditions</a>
                            </li>
                            <li>
                                <a href="#">Privacy Policy</a>
                            </li>
                        </ul>
                        <!--Left Footer Middle Column Content Links-->
                        <ul>
                            <li>
                                <a href="#">Latest news</a>
                            </li>
                            <li>
                                <a href="#">Request a brochure</a>
                            </li>
                            <li>
                                <a href="#">Suscribe to newsletter</a>
                            </li>
                            <li>
                                <a href="#">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                    <!--Footer Content Right Column-->
                    <div id="footerContentBottomRight">
                        <div id="footerContentBottomRightLine">
                        </div>
                        <!--Footer Content Right Column Heading-->
                        <h3>
                            Contact Us
                        </h3>
                        <!--Footer Content Right Column Content-->
                        <ul>
                            <li>
                                <a href="tel:1234567890"><span class="footerContactBoldText">Tel:</span> 12345 67890</a>
                            </li>
                            <li>
                                <a href="mailto:info@naturetour.com"><span class="footerContactBoldText">Email:</span> info@naturetour.com</a>
                            </li>
                        </ul>
                        <p>
                            Naturetour, Your City,<br />Your State, 123 456 789
                        </p>
                    </div>
                </div>
            </div>
            <!--Footer Bottom Copyright and Disclaimer-->
            <div id="footerText">
                <h6>
                    &copy; Naturetour 2010
                </h6>
                <p>
                    No portion of this website may be reproduced without the prior written consent of Naturetour. All rights reserved.
                </p>
            </div>
        </footer>
    <!--End Footer Area-->
    </div>
    <!--End "Wrapper"-->
    
    <?php wp_footer(); ?>
</body>
<!--End Body Section-->
</html>