    <?php get_header(); ?>
        <!--Begin Main Content Area-->
        <!--Div used instead of HTML5 "Main" because IE 11 and below does not recognise it as an element and the background would not display and would not recognise footer top margin-->
        <div id="main">
        <!--Begin Main/Left Content Area-->
            <section>
			<!--Begin Top Article Content Area-->
                <article>
                    <div>
					<!--Loop for top content featured post-->
                    <?php $my_query = new WP_Query( 'category_name=featured&posts_per_page=1' ); ?>
                    <?php while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
                        <span	class="articleHeadingText2"><?php the_title(); ?></span>
                        <p><?php the_excerpt(); ?></p>
                        <a href="<?php the_permalink(); ?>">View new tours...</a>
                        
                    <?php endwhile; ?>
                        <ul>
                            <li>
                                1
                            </li>
                            <li>
                                2
                            </li>
                            <li>
                                3
                            </li>
                            <li>
                                4
                            </li>
                        </ul>
                    </div>
                </article>
                <!--End Top Article Content Area-->
                <!--Begin Bottom Content Area-->
                <!--Bottom Content Heading-->
                <div id="bottomContentHeadingLeft">
                    <h1>
                        Naturetour Wild Life Holidays
                    </h1>
                    <p>
                        A selection of worldwide bird watching, wild flower and natural history holidays (including wildlife tours, treks and cruises), all led by expert <a href="#">naturalist guides.</a>
                    </p>
                </div>
                <div id="bottomContentHeadingRight">
                </div>
                <!--Bottom Content Sort Nav-->
                <div id="bottomContentSortNav">
                    <div>
                        <a href="#">By Destination</a>
                    </div>
                    <div>
                        <a href="#">By Species</a>
                    </div>
                    <div>
                        <a href="#">By Tour Type</a>
                    </div>
                </div>
				<!--Bottom Content Sort-->
				<?php rewind_posts(); ?>
                    <?php $bottom_query = new WP_Query( 'category_name=front-page&posts_per_page=6' ); ?>
                    <?php while ( $bottom_query->have_posts() ) : $bottom_query->the_post(); ?>
                       <div style="width:33%;float:left">
                        <img src="<?php the_post_thumbnail_url(); ?>"/ style="width:95%;" class="tableIMG">
                        <h2><?php the_title(); ?></h2>
						
                        <p><?php the_excerpt(); ?></p>
						
                        <a href="<?php the_permalink(); ?>">...</a>
                        </div>    
                    <?php endwhile; ?>
               
            </section>
        <!--End Main/Left Content Area-->
    <?php get_sidebar(); ?>
    <?php get_footer(); ?>