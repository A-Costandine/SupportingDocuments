    <?php get_header(); ?>
        <!--Begin Main Content Area-->
        <!--Div used instead of HTML5 "Main" because IE 11 and below does not recognise it as an element and the background would not display and would not recognise footer top margin-->
        <div id="main">
        <!--Begin Main/Left Content Area-->
            <section>
<!--Content Area Heading-->
                <div id="contentLeftHeading">
                    <?php $my_query = new WP_Query( 'category_name=species&posts_per_page=1' ); ?>
                    <?php while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
                        <h1><?php the_title(); ?></h1>
                        <?php the_excerpt(); ?>
                        
                    <?php endwhile; ?>
                </div>
                <!--Main Species.html Content-->
                <div id="contentLeft">
				<div id ="speciesContent">
					<?php rewind_posts(); ?>
                    <?php $bottom_query = new WP_Query( 'category_name=species-page&posts_per_page=6' ); ?>
                    <?php while ( $bottom_query->have_posts() ) : $bottom_query->the_post(); ?>
                       <div style="width:50%;float:left">
                        <img src="<?php the_post_thumbnail_url(); ?>"/ style="width:95%;" class="tableIMG">
                        <div class="contentLeftPHeading"><?php the_title(); ?></div>
						
                        <p><?php the_excerpt(); ?></p>

                        <div class="contentLeftButton"><a href="<?php the_permalink(); ?>">Find Out More</a></div>
						
                        </div>    
                    <?php endwhile; ?>
                </div>
				</div>
            </section>
        <!--End Main/Left Content Area-->
    <?php get_sidebar(); ?>
    <?php get_footer(); ?>