<!--Begin Sidebar Content Area-->
            <aside>
				<?php dynamic_sidebar( 'sidebar-1' ); ?>
            </aside>
            <!--End Sidebar Content Area-->
        </div>
        <!--End Main Content Area-->