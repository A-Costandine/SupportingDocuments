<!DOCTYPE html>
<html lang="en">
<!--Begin Head Section-->
<head>
<title>Naturetour</title>
<meta charset="utf-8">
<!--Adds page icon-->
<link rel="icon" href="<?php bloginfo('template_url'); ?>/images/icon-naturetour.png">
<!--Link to css stylesheet-->
<link href="<?php bloginfo('template_url'); ?>/css/style.css" type="text/css" rel="stylesheet">
</head>
<!--End Head Section-->
<?php wp_head();?>
<body>
    <!--Begin "Wrapper"-->
    <div id="wrapper">
        <!--Begin Header Area-->
        <header>
            <!--Begin Header Top Container-->
            <div id="headerTop">
                <!--Begin Header Left Content-->
                <div id="headerLeft">
                    <div id="headerLogo">
                    </div>
                </div>
                <!--End Header Left Content-->
                <!--Begin Header Right Content-->
                <div id="headerRight">
                    <div id="headerPhone">
                        For Friendly, Expert advice call<br />
                        <span class="headerPhoneNum">12 (0) 1234 567890</span>
                    </div>
                    <div id="headerContact">
                        <ul class="headerLinks">
                            <li>
                                <a href="index.html">Home</a>
                            </li>
                            <li>
                                <a href="#">How To Book</a>
                            </li>
                            <li>
                                <a href="#">FAQS</a>
                            </li>
                            <li>
                                <a href="#">Visit Us</a>
                            </li>
                            <li>
                                <a href="mailto:A.Costandine@email.com">Contact Us</a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!--End Header Right Content-->
            </div>
            <!--End Header Top Container-->
            <!--Begin Header Navagation Container-->
            <nav>
                <?php wp_nav_menu( array( 'theme_location' => 'main-menu' ) ); ?>
            </nav>
            <!--End Header Navagation Container-->
        </header>
        <!--End Header Area-->
        <!--Begin Top Breadcrumb Links-->
        <div id="breadcrumbs">
            <span class="breadcrumbsLinkEnd">

			</span>
        </div>
        <!--End Top Breadcrumb Links-->